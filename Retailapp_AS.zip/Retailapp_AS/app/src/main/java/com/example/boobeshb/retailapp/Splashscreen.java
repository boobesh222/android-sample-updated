package com.example.boobeshb.retailapp;

import android.app.Activity;

/**
 * Created by boobeshb on 24-03-2016.
 */
public class Splashscreen extends Activity {


}
