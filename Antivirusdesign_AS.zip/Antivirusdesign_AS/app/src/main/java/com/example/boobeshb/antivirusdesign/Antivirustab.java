package com.example.boobeshb.antivirusdesign;

import android.animation.ObjectAnimator;
import android.app.ActionBar;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TabHost;
import android.widget.Toast;

/**
 * Created by boobeshb on 19-02-2016.
 */
public class Antivirustab extends FragmentActivity{
    ActionBar.Tab scan ,detectedfiles,detectedApps;
    /*Fragment scanfrag=new Scanfrag();
    Fragment detectedfilesfrag=new detectedfiles();
    Fragment detectedappsfrag=new detectedapps();
    */ViewPager vp;
    Tabpageradapter pabadapter;
    //ActionBar actionbar;
    FragmentTabHost frgtabhost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
          requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
          //getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
          setContentView(R.layout.antivirustabs);
          getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.antivirustitle);


        frgtabhost=(FragmentTabHost)findViewById(R.id.main_fragtabhost);
        frgtabhost.setup(getApplicationContext(), getSupportFragmentManager(), android.R.id.tabcontent);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("Scan", null), Scanfrag.class, null);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("Detected  Files", null), detectedfiles.class, null);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("Detected  Apps", null), detectedapps.class, null);
        /*TabHost.LayoutParams thg=new TabHost.LayoutParams(10,10);
        frgtabhost.setLayoutParams(thg);*/
        //frgtabhost.getTabWidget().getChildAt(1).setBackgroundResource(R.drawable.backupsmall);
        //frgtabhost.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        frgtabhost.getTabWidget().getChildAt(0).setBackgroundColor(Color.rgb(238,235,235));
        frgtabhost.getTabWidget().getChildAt(1).setBackgroundColor(Color.rgb(238,235,235));
        frgtabhost.getTabWidget().getChildAt(2).setBackgroundColor(Color.rgb(238,235,235));
        //frgtabhost.getTabWidget().setMinimumHeight(7);
       // frgtabhost.getTabWidget().getA.setBackgroundColor(Color.rgb(238,235,235));
        frgtabhost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                int position=frgtabhost.getCurrentTab();
                vp.setCurrentItem(position);
            }
        });
         pabadapter=new Tabpageradapter(getSupportFragmentManager());
         vp=(ViewPager)findViewById(R.id.virustab_viewpager);
         vp.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                int location=vp.getCurrentItem();
                frgtabhost.setCurrentTab(location);
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
          vp.setAdapter(pabadapter);



/*
        implements TabHost.OnTabChangeListener,ViewPager.OnPageChangeListener {
*/


        /*actionbar=getActionBar();
        actionbar.setCustomView(R.layout.antivirustitle);
        actionbar.setDisplayOptions(actionbar.DISPLAY_SHOW_CUSTOM);
        actionbar.setDisplayShowTitleEnabled(false);
        actionbar.setDisplayUseLogoEnabled(false);
        actionbar.setDisplayShowHomeEnabled(true);
        //actionBar.setDisplayHomeAsUpEnabled(true);

        pabadapter=new Tabpageradapter(getSupportFragmentManager());

        vp=(ViewPager)findViewById(R.id.antivirus_viewpager);
        vp.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                ActionBar ac = getActionBar();
                ac.setSelectedNavigationItem(position);
            }

        });

        vp.setAdapter(pabadapter);


        ActionBar.TabListener tl= new ActionBar.TabListener() {
            @Override
            public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
                vp.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {

            }

            @Override
            public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {

            }
        };

        actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        actionbar.addTab(actionbar.newTab().setText("SCAN").setTabListener(tl));
        actionbar.addTab(actionbar.newTab().setText("detected files").setTabListener(tl));
        actionbar.addTab(actionbar.newTab().setText("detected apps").setTabListener(tl));
*/
    }

/*
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
           int location=vp.getCurrentItem();
            frgtabhost.setCurrentTab(location);
    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public void onTabChanged(String tabId) {
               *//* int position=frgtabhost.getCurrentTab();
                vp.setCurrentItem(position);*//*
    }*/
}


/*
ActionBar actionBar=getActionBar();
actionBar.setCustomView(R.layout.antivirustitle);
        actionBar.setDisplayOptions(actionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(false);
        actionBar.setDisplayShowHomeEnabled(true);
        // actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setNavigationMode(actionBar.NAVIGATION_MODE_TABS);

        scan=actionBar.newTab().setText("SCAN");
        detectedfiles=actionBar.newTab().setText("detectedfiles");
        detectedApps=actionBar.newTab().setText("detectedapps");
        */
/*ProgressBar pbar=(ProgressBar)findViewById(R.id.progressbar);
        ObjectAnimator animation=new ObjectAnimator();

        animation.ofInt(pbar, "progress", 0, 100);
        animation.setDuration(5000);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.start();*//*

        scan.setTabListener(new Tablisteners(scanfrag));
        detectedfiles.setTabListener(new Tablisteners(detectedfilesfrag));
        detectedApps.setTabListener(new Tablisteners(detectedappsfrag));
        actionBar.addTab(scan);
        actionBar.addTab(detectedfiles);
        actionBar.addTab(detectedApps);*/
