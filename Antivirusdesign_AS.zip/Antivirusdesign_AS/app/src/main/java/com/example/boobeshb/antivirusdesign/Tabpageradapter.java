package com.example.boobeshb.antivirusdesign;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.widget.Switch;

/**
 * Created by boobeshb on 23-02-2016.
 */
public class Tabpageradapter extends FragmentStatePagerAdapter {

    public Tabpageradapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch(position){
            case 0 :
                return new Scanfrag();
            case 1 :
                return  new detectedapps();
            case 2:
                return  new detectedfiles();

        }
        return null;
    }

    @Override
    public int getCount() {
        return 3;
    }


}
