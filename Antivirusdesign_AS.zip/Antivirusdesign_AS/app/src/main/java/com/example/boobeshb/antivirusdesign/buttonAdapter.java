package com.example.boobeshb.antivirusdesign;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by boobeshb on 18-02-2016.
 */
public class buttonAdapter extends BaseAdapter {
    Context cc;



    public buttonAdapter(Context c) {
        cc = c;
    }

    @Override
    public int getCount() {

        return buttons();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
          Button button;
        LayoutInflater inf=(LayoutInflater)cc.getSystemService(cc.LAYOUT_INFLATER_SERVICE);
        View returnview ;
        View callmanview;
                   /*button=new Button(cc);
          //  button.setLayoutParams(new GridView.LayoutParams(100, 100));
              button.setBackgroundResource(R.drawable.antivirus);

*/
              System.out.println("POSITION VALUE" +position);
              returnview=inf.inflate(R.layout.individualimages,null);
              ImageView icon=(ImageView)returnview.findViewById(R.id.images);
              TextView desc=(TextView)returnview.findViewById(R.id.imagedescription);
              ImageView wricon=(ImageView)returnview.findViewById(R.id.wrongrighyicon);
              TextView bottomtextview=(TextView)returnview.findViewById(R.id.bottomtextview);
              TextView bottomtextviewtwo=(TextView)returnview.findViewById(R.id.bottomtextviewtwo);
              Date  d=new Date();
              d.getTime();

              callmanview=inf.inflate(R.layout.callmanagerresource,null);
              ImageView cicon=(ImageView)callmanview.findViewById(R.id.images);
              TextView cdesc=(TextView)callmanview.findViewById(R.id.imagedescription);
              ImageView cwricon=(ImageView)callmanview.findViewById(R.id.wrongrighyicon);
              TextView cbottomtextview=(TextView)callmanview.findViewById(R.id.bottomtextview);
              TextView cbottomtextviewtwo=(TextView)callmanview.findViewById(R.id.bottomtextviewtwo);

        SimpleDateFormat sdf=new SimpleDateFormat();
        String formatteddate= sdf.format(d);

        switch (position){
                  case 0:
                       icon.setImageResource(R.drawable.ring);
                       desc.setText("Antivirus");
                       wricon.setImageResource(R.drawable.gright);
                      System.out.println("CASE 1" + position);
                        bottomtextview.setText("Device Clean");
                         bottomtextviewtwo.setText(formatteddate);
                      return returnview;

                  case 1:
                      cicon.setImageResource(R.drawable.call);
                      cdesc.setText("Call Manger");
                       cwricon.setImageResource(R.drawable.gright);
                      System.out.println("CASE 2" + position);
                      //cbottomtextview.setText("blocked calls");
                       //cbottomtextviewtwo.setText("blocked messages");
                      return callmanview;
                  case 2:
                      icon.setImageResource(R.drawable.kid);
                      desc.setText("Parental Control");
                      System.out.println("CASE 3" + position);
                      wricon.setImageResource(R.drawable.cross);
                      //bottomtextview.setText("");
                      //bottomtextviewtwo.setText(formatteddate);
                      return returnview;
                  case 3:
                      icon.setImageResource(R.drawable.lock);
                      desc.setText("Anti Theft");
                      System.out.println("CASE 4" + position);
                      wricon.setImageResource(R.drawable.gright);
                      return returnview;
                   case 4:
                        icon.setImageResource(R.drawable.bk);
                        desc.setText("backup");
                       System.out.println("CASE 5" + position);
                       wricon.setImageResource(R.drawable.clock);
                       //bottomtextviewtwo.setText(formatteddate);
                        return returnview;
              }

              //Button one=(Button)returnview.findViewById(R.id.buttonlay_buttonone);
              /*one.setLayoutParams(new GridView.LayoutParams(25,25));*/
              //one.setBackgroundResource(images[position]);


        return returnview;

    }


    public int  buttons() {
        int count=5;
        return  count;
    }
}
