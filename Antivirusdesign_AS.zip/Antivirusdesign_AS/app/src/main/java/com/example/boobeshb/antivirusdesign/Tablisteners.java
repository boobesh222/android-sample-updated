package com.example.boobeshb.antivirusdesign;

import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentTransaction;

/**
 * Created by boobeshb on 19-02-2016.
 */
public class Tablisteners implements ActionBar.TabListener {
    Fragment fragment;

    public Tablisteners(Fragment a) {
        fragment=a;
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
       // ft.replace(R.id.main_activity,fragment);
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
          ft.remove(fragment);

    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {

    }
}
