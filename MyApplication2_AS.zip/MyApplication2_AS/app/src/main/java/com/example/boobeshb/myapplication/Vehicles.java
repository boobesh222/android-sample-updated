package com.example.boobeshb.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Created by boobeshb on 03-02-2016.
 */
public class Vehicles extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vehicles);


    }


    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(Vehicles.this, "onstart state vehicles", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(Vehicles.this, "onresume vehicles", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(Vehicles.this, "Onpause veh", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(Vehicles.this, "onstop veh", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(Vehicles.this, "Ondestroy veh", Toast.LENGTH_SHORT).show();
    }
}
