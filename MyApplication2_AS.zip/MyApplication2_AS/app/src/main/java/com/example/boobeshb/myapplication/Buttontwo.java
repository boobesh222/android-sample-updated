package com.example.boobeshb.myapplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by boobeshb on 03-02-2016.
 */
public class Buttontwo extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondlayout);
    }
}
