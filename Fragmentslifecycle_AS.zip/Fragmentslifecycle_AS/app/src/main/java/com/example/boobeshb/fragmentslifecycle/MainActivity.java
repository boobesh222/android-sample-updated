package com.example.boobeshb.fragmentslifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button apple=(Button)findViewById(R.id.applebutton);
        Button samsung=(Button)findViewById(R.id.samsungbutton);


        apple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment apple=new Fragmentone();

                /*FragmentManager  fm=getFragmentManager();
                FragmentTransaction  ft=fm.beginTransaction();
                ft.remove(apple);
                ft.add(apple, "appletag");
                ft.isEmpty();
                System.out.println(ft.isEmpty() + "IS EMPTY");
                ft.commit();*/

                getFragmentManager().beginTransaction()
                        .replace(R.id.framelayout1, apple, null).commit();


            }
        });

        samsung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment samsung=new Fragmenttwo();
                /*FragmentManager fm=getFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.framelayout, samsung);
                Toast.makeText(MainActivity.this, "Samsung CLICKED", Toast.LENGTH_SHORT).show();
                ft.commit();*/

                getFragmentManager().beginTransaction()
                        .replace(R.id.framelayout1, samsung, null).commit();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
            // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
