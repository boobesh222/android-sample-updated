//
//  main.m
//  samplescreendesign
//
//  Created by Bharanidharan P on 8/1/16.
//  Copyright © 2016 sensiple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
