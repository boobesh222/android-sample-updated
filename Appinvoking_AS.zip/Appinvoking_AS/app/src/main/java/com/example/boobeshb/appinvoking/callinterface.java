package com.example.boobeshb.appinvoking;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by boobeshb on 17-02-2016.
 */
public class callinterface extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.callinterface);

        Bundle bundle=getIntent().getExtras();
       // Toast.makeText(getApplicationContext(),bundle.getString("phone"),Toast.LENGTH_SHORT).show();
        TextView a=(TextView)findViewById(R.id.main_incomingcall);
        a.setText("Incoming call " + " "
                + bundle.getString("phone"));
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(getApplicationContext(),"finished",Toast.LENGTH_LONG).show();
        finish();

    }
}
