package com.example.boobeshb.carrental;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    ListView lv;
    int images[]={R.drawable.persons,R.drawable.chiller,R.drawable.cfive,R.drawable.gpattern,R.drawable.heater,R.drawable.acauto};
    int pickup[]={R.drawable.airport,R.drawable.meet};
    int carslogo[]={R.drawable.carsone,R.drawable.cars,R.drawable.carsthree,R.drawable.carsfour};
    int cmpylogo[]={R.drawable.c,R.drawable.ctwo,R.drawable.ctwo,R.drawable.cthree};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_main);
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,R.layout.customtitlebar);

        TextView results=(TextView)findViewById(R.id.results);
        results.setText("287 results in Los Angels Airport ");

        lv=(ListView)findViewById(R.id.main_listview);
        lv.setAdapter(new Customadapter(getApplicationContext(),images,pickup,carslogo,cmpylogo));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "clicked" + position, Toast.LENGTH_SHORT).show();
               /* System.out.print( " CHILD COUNT "+lv.getChildCount());*/
                         // View selectedview=parent.getSelectedView();
                Object listposition=parent.getItemAtPosition(position);
                System.out.println("listposition" + parent.getItemAtPosition(position));

                TextView listview_modelname=(TextView)view.findViewById(R.id.listview_modelname);
                TextView reviews=(TextView)view.findViewById(R.id.reviews);
                TextView price=(TextView)view.findViewById(R.id.price);
                TextView hirerate=(TextView)view.findViewById(R.id.hirerate);
                RatingBar s=(RatingBar)view.findViewById(R.id.ratingbar);

                ImageView carimage=(ImageView)view.findViewById(R.id.carimage);

                int carid=carimage.getId();
                Intent a=new Intent(getApplicationContext(),Nextscreen.class);
                a.putExtra("heading",listview_modelname.getText().toString());
                a.putExtra("iconone",images[0]);
                a.putExtra("icontwo", images[1]);
                a.putExtra("iconthree",images[2]);
                a.putExtra("iconfour", images[3]);
                a.putExtra("iconfive",images[4]);
                a.putExtra("iconsix",images[5]);
                a.putExtra("carimage",carslogo[position]);
                if(position%2==0){
                    a.putExtra("meet",pickup[0]);

                }else
                {
                    a.putExtra("meet",pickup[1]);

                }
                a.putExtra("cmpylogo",cmpylogo[position]);
                a.putExtra("reviews",reviews.getText().toString());
                a.putExtra("price",price.getText().toString());
                a.putExtra("hirerate",hirerate.getText().toString());
                a.putExtra("rating",s.getRating());
                 startActivity(a);

                /*ImageView carlogo=(ImageView)selectedview.findViewById(R.id.carimage);
                  ImageView aa=(ImageView)view.findViewById(R.id.image1);
                 System.out.println("values" + parent.getItemAtPosition(position).toString());
                System.out.println("child count"+ parent.getChildCount());
                LinearLayout childlayout=(LinearLayout)parent.getChildAt(0);
                LinearLayout nestchild=(LinearLayout)childlayout.getChildAt(0);
                LinearLayout logo=(LinearLayout)nestchild.getChildAt(0);
                LinearLayout name=(LinearLayout)logo.getChildAt(0);
                TextView s=(TextView)name.getChildAt(0);
                System.out.println(s.getText().toString() + "childvalue");
                System.out.println("count values"+ parent.getCount());
                System.out.println("id values"+ parent.getItemIdAtPosition(position));
                int tag=Integer.parseInt(aa.getTag().toString());
                System.out.println("tag value"+ tag);
                SharedPreferences preference=getSharedPreferences("details",MODE_WORLD_READABLE);
                SharedPreferences.Editor editor=preference.edit();
                editor.putInt("imagesperson",tag);
                editor.commit();
*/
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
