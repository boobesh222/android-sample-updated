package com.example.boobeshb.carrental;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by boobeshb on 29-02-2016.
 */
public class Nextscreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.next);

        Bundle x=getIntent().getExtras();

        TextView listview_modelname=(TextView)findViewById(R.id.name);
        TextView reviews=(TextView)findViewById(R.id.next_reviews);
        ImageView car=(ImageView)findViewById(R.id.carnexticon);
        ImageView imageviewone=(ImageView)findViewById(R.id.imageviewone);
        ImageView imageviewtwo=(ImageView)findViewById(R.id.imageviewtwo);
        ImageView iconsone=(ImageView)findViewById(R.id.iconsone);
        ImageView iconstwo=(ImageView)findViewById(R.id.iconstwo);
        ImageView iconsthree=(ImageView)findViewById(R.id.iconsthree);
        ImageView meetairport=(ImageView)findViewById(R.id.meetairport);
        ImageView cmpyicon=(ImageView)findViewById(R.id.cmpyicon);
        ImageView clockicon=(ImageView)findViewById(R.id.clockicon);
        ImageView clockicond=(ImageView)findViewById(R.id.clockicond);
        TextView mileage=(TextView)findViewById(R.id.mileage);
        TextView cancellation=(TextView)findViewById(R.id.cancellation);
        TextView carmodel=(TextView)findViewById(R.id.carmodel);
        TextView modeldesc=(TextView)findViewById(R.id.modeldesc);
        TextView fuelpolicy=(TextView)findViewById(R.id.fuelpolicy);
        TextView fueldesc=(TextView)findViewById(R.id.fueldesc);
        TextView pickupdetails=(TextView)findViewById(R.id.pickupdetails);
        TextView pickuptime=(TextView)findViewById(R.id.pickuptime);
        TextView dropoff=(TextView)findViewById(R.id.dropoff);
        TextView dropoffdetails=(TextView)findViewById(R.id.dropoffdetails);
        TextView pickup=(TextView)findViewById(R.id.pickup);
        TextView dropofftime=(TextView)findViewById(R.id.dropofftime);
        TextView address=(TextView)findViewById(R.id.address);
        TextView addressdetails=(TextView)findViewById(R.id.addressdetails);
        TextView roadassitance=(TextView)findViewById(R.id.roadassitance);


        listview_modelname.setText(x.getString("heading"));
        reviews.setText(x.getString("reviews"));
        car.setImageResource(x.getInt("carimage"));
        imageviewone.setImageResource(x.getInt("iconone"));
        imageviewtwo.setImageResource(x.getInt("icontwo"));
        iconsone.setImageResource(x.getInt("iconthree"));
        iconstwo.setImageResource(x.getInt("iconfour"));
        iconsthree.setImageResource(x.getInt("iconfive"));
        meetairport.setImageResource(x.getInt("meet"));
        cmpyicon.setImageResource(x.getInt("cmpylogo"));
        mileage.setText("* unlimited mileage");
        cancellation.setText(" * free cancellation");
        roadassitance.setText("* 24/7 assistance");
        carmodel.setText(" Car Type");
        modeldesc.setText("ford or similar");
        fuelpolicy.setText("Fuel Policy");
        fueldesc.setText("End to End ");
        pickup.setText("Pick Up");
        pickupdetails.setText("Fri Apr 15,2016");
        pickuptime.setText("12.00 Pm");
        dropoff.setText("Drop Off");
        dropoffdetails.setText("Fri Apr 16,2016");
        dropofftime.setText("5.00 Pm");
        address.setText("Address");
        addressdetails.setText("Los Angels Airport");
        clockicon.setImageResource(R.drawable.clock);
        clockicond.setImageResource(R.drawable.clock);
    }
}
