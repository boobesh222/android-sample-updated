package com.example.boobeshb.imagecropping;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by boobeshb on 18-05-2016.
 */
public class drawrectangle  extends View {

    private Paint mrectpaint;
    private int mstartx;
    private int mstarty;
    private int mendx;
    private int mendy;
    private boolean mdrawreactangle=false;
    private TextPaint mtextPaint=null;
    private OnUpCallBack mcallback=null;

    public interface OnUpCallBack{
        void onRectFinished(Rect rect);

    }

    public drawrectangle(Context context) {
        super(context);
        init();
    }

    public drawrectangle(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();

    }


    public drawrectangle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();


    }

    public void setOnupcallback(OnUpCallBack callback){
        mcallback=callback;
    }


    public void init(){
        mrectpaint=new Paint();
        mrectpaint.setColor(getContext().getResources().getColor(android.R.color.holo_green_light));
        mrectpaint.setStyle(Paint.Style.STROKE);
        mrectpaint.setStrokeWidth(5);

        mtextPaint=new TextPaint();
        mtextPaint.setColor(getContext().getResources().getColor(android.R.color.holo_green_dark));
        mtextPaint.setTextSize(20);
    }

 @Override
    public  boolean onTouchEvent(final MotionEvent event){
      switch(event.getAction()){
          case MotionEvent.ACTION_DOWN:
              mdrawreactangle=false;
              mstartx=(int)event.getX();
              System.out.println("");
              mstarty=(int)event.getY();
              invalidate();
              break;
          case MotionEvent.ACTION_MOVE:
              final int x =(int)event.getX();
              final int y= (int)event.getY();

              if(!mdrawreactangle||Math.abs(x-mendx) > 5||Math.abs(y-mendy) > 5){
                    mendx=x;
                  mendy=y;
                  invalidate();
              }
                 mdrawreactangle=true;


             // invalidate();
              break;
          case MotionEvent.ACTION_UP:
              if(mcallback != null){
                   mcallback.onRectFinished(new Rect(Math.min(mstartx, mendx), Math.min(mstarty, mendy), Math.min(mendx, mstartx), Math.min(mendy, mstartx)));
                  invalidate();
                  break;
              }
          default:
              break;
      }
     return true;
 }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(mdrawreactangle){
        canvas.drawRect(Math.min(mstartx, mendx), Math.min(mstarty, mendy), Math.min(mendx, mstartx), Math.min(mendy, mstartx),mrectpaint);
            canvas.drawText("  (" + Math.abs(mstartx - mendx) + ", " + Math.abs(mstarty - mendy) + ")",
                    Math.max(mendx, mstartx), Math.max(mendy, mstarty), mtextPaint);
        }
    }
}
