package com.android.youtubeapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.android.youtube.player.YouTubePlayer.Provider;

/**
 * Created by boobeshb on 04-07-2016.
 */
public class youtubevideo extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {
   public  final String YOUTUBE_KEY="AIzaSyAQSs2STiZV-Trg-t3PIQSCXMHOOO_zCRQ";
    //public static final String VIDEO_ID = "_KN-5zmvjAo";/* dKLftgvYsVU*/

    public static  String VIDEO_ID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

        setContentView(R.layout.youtubelayout);
        //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebarlayout);

        VIDEO_ID=getIntent().getStringExtra("links");
        YouTubePlayerView  youTubePlayerView=(YouTubePlayerView)findViewById(R.id.youtube_player);
        youTubePlayerView.initialize(YOUTUBE_KEY,this);

    }

    @Override
    public void onInitializationSuccess(Provider provider, YouTubePlayer youTubePlayer, boolean b) {
           System.out.println("INITIALIZATION SUCCESS ");
        if(!b){
            youTubePlayer.cueVideo(VIDEO_ID);
        }
    }

    @Override
    public void onInitializationFailure(Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
         System.out.println("Initialization failure ");
    }
}
