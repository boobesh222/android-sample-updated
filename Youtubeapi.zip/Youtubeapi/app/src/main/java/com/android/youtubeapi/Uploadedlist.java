package com.android.youtubeapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by boobeshb on 05-07-2016.
 */
public class Uploadedlist extends Activity {

     public ListView uploadedVideoList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

        setContentView(R.layout.uploadeditemslist);
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebarlayout);

        uploadedVideoList =(ListView)findViewById(R.id.videosListview);
        uploadedVideoList.setAdapter(new Listviewadapter(getApplicationContext()));
        uploadedVideoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent youtubeintent = new Intent(getApplication(), youtubevideo.class);
                youtubeintent.putExtra("links", ((TextView) view.findViewById(R.id.TextviewOnlist)).getText().toString().substring(32));
                startActivity(youtubeintent);
            }
        });

        uploadedVideoList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent shareIntent =
                        new Intent(android.content.Intent.ACTION_SEND);

                //set the type
                shareIntent.setType("text/plain");

                //add a subject
                shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                        "Video Link");

                //build the body of the message to be shared
                String shareMessage = "" + ((TextView) view.findViewById(R.id.TextviewOnlist)).getText();

                //add the message
                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                        shareMessage);

                //start the chooser for sharing
                startActivity(Intent.createChooser(shareIntent,
                        "Please choose the app"));

                return true;
            }
        });
    }
}
