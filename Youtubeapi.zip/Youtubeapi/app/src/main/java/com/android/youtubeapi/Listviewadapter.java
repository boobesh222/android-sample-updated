package com.android.youtubeapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by boobeshb on 05-07-2016.
 */
public class Listviewadapter extends BaseAdapter {
     public Context context;
     public String youtubelinks[]={"_KN-5zmvjAo"};
     public int thumbnails[]={R.drawable.video};
    public LayoutInflater inflater;


    public Listviewadapter(Context context) {
         this.context=context;

    }

    @Override
    public int getCount() {
        return 1;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View customlistview=LayoutInflater.from(context).inflate(R.layout.customlistview,null);
         customlistview.findViewById(R.id.ImageviewOnList).setBackgroundResource(R.drawable.video);
        TextView textView=(TextView) customlistview.findViewById(R.id.TextviewOnlist);
        textView.setText("https://www.youtube.com/watch?v="+youtubelinks[i]);
        return  customlistview;

    }
}
