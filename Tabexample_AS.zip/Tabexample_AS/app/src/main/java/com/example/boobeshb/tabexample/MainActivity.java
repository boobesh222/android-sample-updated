package com.example.boobeshb.tabexample;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;

public class MainActivity extends FragmentActivity {

    FragmentTabHost frgtabhost;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frgtabhost=(FragmentTabHost)findViewById(R.id.main_fragtabhost);
        frgtabhost.setup(getApplicationContext(),getSupportFragmentManager(),android.R.id.tabcontent);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("tab 1", null), Fragmenttab.class, null);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("tab 2",null),Fragmenttab.class, null);
        frgtabhost.addTab(frgtabhost.newTabSpec("").setIndicator("tab 3",null),Iamge.class,null);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
