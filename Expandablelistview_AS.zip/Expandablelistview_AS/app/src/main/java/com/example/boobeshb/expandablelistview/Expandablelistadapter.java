package com.example.boobeshb.expandablelistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by boobeshb on 17-03-2016.
 */
public class Expandablelistadapter extends BaseExpandableListAdapter  {

    Context context;
    List <String > _listdataheader;
    HashMap <String ,List<String>> _listchildheader;
    public static List<String> values =new ArrayList<String>();



    public Expandablelistadapter(Context c,List<String> list,HashMap<String,List<String>> map) {
        super();
         context=c;
        _listdataheader=list;
        _listchildheader=map;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return _listchildheader.get(this._listdataheader.get(groupPosition))
                .get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final String childvalue=(String)getChild(groupPosition, childPosition);
        if (groupPosition==0) {
            LayoutInflater inf = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inf.inflate(R.layout.listitem, null);
            final EditText tvone=(EditText)convertView.findViewById(R.id.editone);
            final EditText etwo=(EditText)convertView.findViewById(R.id.edittwo);
            final EditText ethree=(EditText)convertView.findViewById(R.id.editthree);
            Button submit=(Button)convertView.findViewById(R.id.submit);
            values.add(tvone.getText().toString());
            values.add(etwo.getText().toString());
            values.add(ethree.getText().toString());

            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, "" + childvalue + tvone.getText() + etwo.getText() + ethree.getText(), Toast.LENGTH_SHORT).show();

                }
            });


            return convertView;
        }


        if (groupPosition==1) {
            LayoutInflater inf = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inf.inflate(R.layout.secondlayout, null);
            checklistsize();
            return convertView;
        }

        /* EditText tvlist=(EditText)convertView.findViewById(R.id.listitem_edittext);
        tvlist.setText(childvalue);
        tvlist.getText();
        Toast.makeText(context, tvlist.getText(), Toast.LENGTH_SHORT).show();
        tvlist.setFocusableInTouchMode(true);
        Button b=(Button)convertView.findViewById(R.id.submit);
        b.setVisibility(View.INVISIBLE);
        System.out.println(_listchildheader.get(_listdataheader.get(groupPosition)).size());
        System.out.println(childPosition + "CHILD POSITION AND LIST SIZE" + _listchildheader.get(_listdataheader.get(groupPosition)).size() );
        if(childPosition==((_listchildheader.get(_listdataheader.get(groupPosition)).size())-1)){
            b.setVisibility(View.VISIBLE);
        }*/
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return _listchildheader.get(_listdataheader.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return _listdataheader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return _listdataheader.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String grouptext=(String)getGroup(groupPosition);
        System.out.println(grouptext + "grouptext");

        if(convertView==null){
            LayoutInflater inf=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inf.inflate(R.layout.listgroup,null);
        }

        TextView tv=(TextView)convertView.findViewById(R.id.listgroup_textview);
        tv.setText(grouptext);
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }


    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

     public void checklistsize(){
         for (String s:values
              ) {
             System.out.println("values " + s);
         }
     }
}
