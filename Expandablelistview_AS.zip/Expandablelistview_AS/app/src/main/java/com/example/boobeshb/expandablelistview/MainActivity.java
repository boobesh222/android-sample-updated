package com.example.boobeshb.expandablelistview;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends Activity {

    Expandablelistadapter eladapter;
    ExpandableListView listviewex;
    List<String> header=new ArrayList<String>();
    HashMap<String,List<String>> map=new HashMap<String,List<String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listviewex=(ExpandableListView)findViewById(R.id.main_exlistview);
        preparedata();

        eladapter=new Expandablelistadapter(getApplicationContext(),header,map);
        listviewex.setAdapter(eladapter);

        /*listviewex.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
           *//*     TextView ed = (TextView) v.findViewById(R.id.listitem_edittext);
                ed.setFocusable(false);
                ed.getText();
                System.out.println("EDITTEXT VALUE" + ed.getText());
           *//*     Toast.makeText(MainActivity.this,"hai", Toast.LENGTH_LONG).show();
                return true;
            }
        });*/

        listviewex.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                Toast.makeText(MainActivity.this, "GROUP CLICKED", Toast.LENGTH_SHORT).show();
                return false;
            }
        });

         listviewex.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
             @Override
             public void onGroupExpand(int groupPosition) {
                 List<String> values = eladapter.values;
                 System.out.println("VALUES Expand listener" + values.size());
                 for (String s : values) {
                     Toast.makeText(MainActivity.this, "you have entered" + s, Toast.LENGTH_SHORT).show();

                 }
             }
         });

         listviewex.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
             @Override
             public void onGroupCollapse(int groupPosition) {
                 Toast.makeText(MainActivity.this, "GROUP COLLAPSED ", Toast.LENGTH_SHORT).show();
             }
         });
    }

    public void preparedata(){
        header.add("personal details");
        header.add("work details");
        header.add("medical details");

        List<String> movies=new ArrayList<String>();
        movies.add("conjuring");
        List<String> cartoons=new ArrayList<String>();
        cartoons.add("scooby doo");

        map.put(header.get(0), movies);
        map.put(header.get(1),cartoons);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
