package com.example.boobeshb.mapsexercise;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by boobeshb on 07-04-2016.
 */
public class dbhelper extends SQLiteOpenHelper {

    public dbhelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query="CREATE TABLE IF NOT EXISTS LOCATIONDETAILS (SNO INT PRIMARY KEY,NAME VARCHAR(50),LATITUDE DOUBLE(50),LONGITUDE DOUBLE(50),LOCATION VARCHAR(50) )";
        db.execSQL(query);
        System.out.println("table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}
