package com.example.boobeshb.mapsexercise;

import android.location.Location;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;

/**
 * Created by boobeshb on 06-04-2016.
 */
/*
public class Mapfragment extends SupportMapFragment implements GoogleApiClient.ConnectionCallbacks,
          GoogleApiClient.OnConnectionFailedListener,
        GoogleMap.OnInfoWindowClickListener,
GoogleMap.OnMapLongClickListener,
GoogleMap.OnMapClickListener,
GoogleMap.OnMarkerClickListener{

    private GoogleApiClient mgoogleapiclient;
    private Location mlocation;
    private  final int[] Maps_types={GoogleMap.MAP_TYPE_TERRAIN,GoogleMap.MAP_TYPE_HYBRID,GoogleMap.MAP_TYPE_NORMAL,GoogleMap.MAP_TYPE_NONE,GoogleMap.MAP_TYPE_SATELLITE};
    private int index=0;


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setHasOptionsMenu(true);
        mgoogleapiclient=new GoogleApiClient.Builder(getActivity()).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
    }
}
*/
