package com.android.sensiple.locationretro;

import com.example.boobeshb.retroexample.classes.Category;
import com.example.boobeshb.retroexample.classes.Curator;
import com.example.boobeshb.retroexample.classes.Sample;
import com.example.boobeshb.retroexample.classes.Vehicles;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by boobeshb on 26-04-2016.
 */
public interface VehicleService {



    @GET("expense_category.json")
    Call<List<Category>> getCategories();

}
