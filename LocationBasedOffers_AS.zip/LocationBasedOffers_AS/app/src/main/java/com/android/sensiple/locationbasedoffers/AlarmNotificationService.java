package com.android.sensiple.locationbasedoffers;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.widget.Toast;

/**
 * Created by boobeshb on 02-06-2016.
 */
public class AlarmNotificationService extends WakefulBroadcastReceiver {

    private NotificationManager mAlarmNotificationManager;

    @SuppressWarnings({"deprecation", "static-access"})
    @Override
    public void onReceive(final Context context, Intent intent) {

        Toast.makeText(context, "b reeiver", Toast.LENGTH_SHORT).show();

        /*mAlarmNotificationManager = (NotificationManager) context
                .getSystemService(context.NOTIFICATION_SERVICE);

        Intent intentNotify = new Intent(Intent.ACTION_MAIN);
        intentNotify
                .setComponent(new ComponentName(
                        "com.android.settings",
                        "com.android.settings.Settings$DataUsageSummaryActivity"));
        intentNotify.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
                context, 0, intentNotify,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | PendingIntent.FLAG_ONE_SHOT);

        Notification.Builder builder = new Notification.Builder(
                context);
        builder.setAutoCancel(true);
        builder.setContentTitle("SARC");
        builder.setContentText("Enable Mobile Data to sync with SARC");
        builder.setContentIntent(contentIntent);
        builder.build();
        Notification notification = builder.getNotification();
        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        notification.defaults |= Notification.DEFAULT_ALL;
        notification.defaults |= Notification.FLAG_INSISTENT;
        notification.defaults |= Notification.FLAG_AUTO_CANCEL;
        notification.defaults |= Notification.DEFAULT_LIGHTS;
        mAlarmNotificationManager.notify(0, notification);
*/

        System.out.println("On broadcast receiver ");

    }

}