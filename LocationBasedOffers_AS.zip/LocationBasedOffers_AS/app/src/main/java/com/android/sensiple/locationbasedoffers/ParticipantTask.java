package com.android.sensiple.locationbasedoffers;

import android.os.AsyncTask;

/**
 * Created by boobeshb on 02-06-2016.
 */
public class ParticipantTask extends AsyncTask {

    @Override
    protected Object doInBackground(Object[] objects) {


        return null;
    }
}
