package com.android.sensiple.locationbasedoffers;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Calendar;

public class SplashActivity extends Activity implements LocationListener {

    public Context mContext;
    AlarmManager alarmManager;

    PendingIntent pendingIntent;
    private PendingIntent pendingIntent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        LocationManager locationmanager=(LocationManager)getSystemService(Context.LOCATION_SERVICE);
        if ( Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return  ;
        }
        locationmanager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,SplashActivity.this);

       /* alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
         setAlarmNotificationDataSync();
*/



    }

    void setAlarmNotificationDataSync() {

        Calendar calendar1 = Calendar.getInstance();

        System.out.println("1");
        calendar1.set(Calendar.HOUR_OF_DAY, 18);
        calendar1.set(Calendar.MINUTE, 02);

        Intent myIntent1 = new Intent(SplashActivity.this,
                AlarmNotificationService.class);

        System.out.println("2");


        pendingIntent = PendingIntent.getBroadcast(SplashActivity.this, 0,
                myIntent1, PendingIntent.FLAG_ONE_SHOT);

        alarmManager
                .setRepeating(AlarmManager.RTC_WAKEUP,
                        calendar1.getTimeInMillis(), 24 * 60 * 60 * 1000,
                        pendingIntent);

        System.out.println("3");


    }

    @Override
    public void onLocationChanged(Location location) {
        System.out.println("location "+ location.getLatitude()+ " " + location.getLongitude());
        Toast.makeText(SplashActivity.this, " on location changed " +location.getLatitude()+ " " + location.getLongitude() , Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_splash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
