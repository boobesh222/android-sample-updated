package com.example.boobeshb.expertcomponentsexample.classes;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/**
 * Created by boobeshb on 06-05-2016.
 */
public class Stackitem {

    public Drawable stackitemimage;


    public Stackitem(Drawable stackitemimage) {
        this.stackitemimage = stackitemimage;
    }
}
