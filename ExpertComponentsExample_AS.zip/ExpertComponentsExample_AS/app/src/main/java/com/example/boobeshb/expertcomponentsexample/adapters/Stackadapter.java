package com.example.boobeshb.expertcomponentsexample.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.example.boobeshb.expertcomponentsexample.R;
import com.example.boobeshb.expertcomponentsexample.classes.Stackitem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 06-05-2016.
 */
public class Stackadapter extends ArrayAdapter<Stackitem> {

    ArrayList<Stackitem> items;
    Context context;
    int resourceid;

    public Stackadapter(Context context, int resource, ArrayList<Stackitem> objects) {
        super(context, resource, objects);

        this.items = objects;
        this.context = context;
        this.resourceid=resource;
    }


    @Override
    public int getCount() {
        return items.size();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater c=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v=c.inflate(R.layout.stackviewlayout,null);
        ImageView imageview=(ImageView)v.findViewById(R.id.stackview_image);
       // Stackitem obj=items.get(position);
        imageview.setImageResource(R.drawable.android);
        return v;
    }
}
