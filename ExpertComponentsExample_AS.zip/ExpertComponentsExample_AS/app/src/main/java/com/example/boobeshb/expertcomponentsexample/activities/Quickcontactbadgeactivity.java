package com.example.boobeshb.expertcomponentsexample.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.QuickContactBadge;

import com.example.boobeshb.expertcomponentsexample.R;

/**
 * Created by boobeshb on 03-05-2016.
 */
public class Quickcontactbadgeactivity extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.badge);

        Button choosecontact=(Button)findViewById(R.id.badge_choosecontact);
       /* QuickContactBadge badgesmall=(QuickContactBadge)findViewById(R.id.contactbadge_small);
       // badgesmall.assignContactFromPhone("9600498811",false);
        badgesmall.assignContactFromEmail("johnm.edu", true);
        badgesmall.setMode(ContactsContract.QuickContact.MODE_SMALL);*/

        choosecontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK,ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, 100);
            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode==RESULT_OK){
            switch (requestCode){
                case 100:
                    Uri uri=data.getData();
                    FrameLayout frameLayout=(FrameLayout)findViewById(R.id.badge_framelayout);
                    QuickContactBadge badgelarge=new QuickContactBadge(getApplicationContext());
                    badgelarge.assignContactUri(uri);
                    badgelarge.setMode(ContactsContract.QuickContact.MODE_LARGE);
                    badgelarge.setImageResource(R.drawable.android);
                    frameLayout.addView(badgelarge);
                    break;


            }
        }
    }
}
