package com.example.boobeshb.expertcomponentsexample.activities;

import android.app.Activity;
import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.Prediction;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewStub;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterViewFlipper;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.MultiAutoCompleteTextView;
import android.widget.NumberPicker;
import android.widget.QuickContactBadge;
import android.widget.StackView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;
import android.widget.ViewSwitcher;
import android.widget.ZoomButton;
import android.widget.ZoomControls;

import com.example.boobeshb.expertcomponentsexample.R;
import com.example.boobeshb.expertcomponentsexample.adapters.Stackadapter;
import com.example.boobeshb.expertcomponentsexample.adapters.componentslistadapter;
import com.example.boobeshb.expertcomponentsexample.classes.Specialcomponents;
import com.example.boobeshb.expertcomponentsexample.classes.Stackitem;

import java.lang.reflect.Array;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;

/**
 * Created by boobeshb on 04-05-2016.
 */
public class Componentexplanation extends Activity {
    GestureLibrary gestureLibrary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GestureOverlayView gestureOverlayView = new GestureOverlayView(getApplicationContext());
        View inflatedview = getLayoutInflater().inflate(R.layout.componentexplanation, null);
        gestureOverlayView.addView(inflatedview);
        gestureLibrary = GestureLibraries.fromRawResource(getApplicationContext(), R.raw.gestures);
        if (gestureLibrary.load()) {
            System.out.println("GESTURE LOADED");
        }
        gestureOverlayView.addOnGesturePerformedListener(new GestureOverlayView.OnGesturePerformedListener() {
            @Override
            public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
                ArrayList<Prediction> predictions = gestureLibrary.recognize(gesture);
                for (Prediction p : predictions) {
                    if (p.score > 1.0) {
                        Toast.makeText(Componentexplanation.this, "prediction name " + p.name, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        setContentView(gestureOverlayView);


        Bundle values = getIntent().getExtras();
        Integer position = values.getInt("positionvalue");
        if (position == null) {
            System.out.println("position " + position);
        }
        int id = Specialcomponents.componentId.get(position);


        /*for making particular view visible*/

        LinearLayout linearLayout = (LinearLayout)findViewById(id);
        System.out.println(linearLayout.getVisibility());
        if (linearLayout != null)
            linearLayout.setVisibility(View.VISIBLE);
        View view = linearLayout.getChildAt(0);
        view.getId();
        System.out.println(linearLayout.getChildCount() + " " + view.isShown() + " " + view.getId() + "  " + view.getVisibility() + "  " + linearLayout.getVisibility());
        view.setVisibility(view.VISIBLE);

        /* for quick contact badge operations */
        Button choosecontact = (Button) findViewById(R.id.badge_choosecontact);
        choosecontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intent, 100);

            }
        });


        /*AUTO COMPLETE TEXTVIEW */
        AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.cx_actextview);
        String languagesnames[] = {"java", "c", "c++", "perl"};
        //autoCompleteTextView.setTextColor();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, languagesnames);
        autoCompleteTextView.setAdapter(arrayAdapter);
        autoCompleteTextView.setThreshold(1);
        autoCompleteTextView.setDropDownBackgroundResource(R.drawable.android);


       /*MULTI AUTOCOMPLETE TEXTVIEW*/

        MultiAutoCompleteTextView multiAutoCompleteTextView = (MultiAutoCompleteTextView) findViewById(R.id.cx_mactextview);
        multiAutoCompleteTextView.setAdapter(arrayAdapter);
        multiAutoCompleteTextView.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        int minimum = 10;
        int maximum = 100;

       /*number picker */
        final TextView hours = (TextView) findViewById(R.id.hours);
        final TextView minutes = (TextView) findViewById(R.id.minutes);
        NumberPicker np1 = new NumberPicker(getApplicationContext());
        NumberPicker np2 = new NumberPicker(getApplicationContext());

        //final String[] valuesstr= {"Red","Green", "Blue", "Yellow", "Magenta"};
        final String[] displayedvalues = new String[91];
        np1.setMinValue(minimum);
        np1.setMaxValue(maximum);
       // np1.setDisplayedValues(displayedvalues);

        np2.setMinValue(0);
        np2.setMaxValue(60);
        np1.setWrapSelectorWheel(false);
        np2.setWrapSelectorWheel(true);
       // np2.setDisplayedValues(displayedvalues);
        np1.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                hours.setText(newVal);

            }
        });

        np2.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                minutes.setText(newVal);
            }
        });




        /*ZOOM BUTTON */
        final ImageView imageView = (ImageView) findViewById(R.id.cx_imageviewzoom);
        ZoomButton zoomButton = (ZoomButton) findViewById(R.id.cx_zoombutton);
        zoomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = imageView.getScaleX();
                float y = imageView.getScaleY();
                imageView.setScaleX(x + 2);
                imageView.setScaleY(y + 2);
            }
        });


        /*zoom controls */
        final ImageView imageView1 = (ImageView) findViewById(R.id.zoomcontrolsimageview);
        ZoomControls zoomControls = (ZoomControls) findViewById(R.id.cx_zoomcontrols);
        zoomControls.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = imageView1.getScaleX();
                float y = imageView1.getScaleY();
                imageView1.setScaleX(x + 2);
                imageView1.setScaleY(y + 2);
            }
        });

        zoomControls.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = imageView1.getScaleX();
                float y = imageView1.getScaleY();
                imageView1.setScaleX(x - 2);
                imageView1.setScaleY(y - 2);
            }
        });


        /*media controller */
        MediaController mediaController = new MediaController(this);
        mediaController.setEnabled(true);
        VideoView videoView = (VideoView) findViewById(R.id.cx_videoview);


        // mediaController.setAnchorView(videoView);
        String s = "http://www.ebookfrenzy.com/android_book/movie.mp4";
        //videoView.setVideoPath("http://www.ebookfrenzy.com/android_book/movie.mp4");
        videoView.setVideoURI(Uri.parse(Environment.getExternalStorageDirectory().getPath() + "/media/1.mp4"));
        videoView.setMediaController(mediaController);
        videoView.start();


       /*gesture overlay view*/
          /*mentioned at the top before setting view*/


        /*view animator*/


        Button nextbuton = (Button) findViewById(R.id.vanext);
        Button previousbutton = (Button) findViewById(R.id.vaprevious);
        final ViewAnimator viewanimator = (ViewAnimator) findViewById(R.id.viewanimator);
        Animation inanimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.slide_in_left);
        Animation outanimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.fade_out);
        viewanimator.setInAnimation(inanimation);
        viewanimator.setOutAnimation(outanimation);
        viewanimator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewanimator.showNext();
            }
        });

        nextbuton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewanimator.showNext();
            }
        });

        previousbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewanimator.showPrevious();
            }
        });


        /*view flipper */
        ViewFlipper viewFlipper = (ViewFlipper) findViewById(R.id.cx_viewflipper);
        viewFlipper.setFlipInterval(5000);
        viewFlipper.startFlipping();


        /*view switcher */
        ImageView imageView2 = new ImageView(getApplicationContext());
        imageView2.setImageResource(R.drawable.android);
        ImageView imageView3 = new ImageView(getApplicationContext());
        imageView3.setImageResource(R.drawable.one);
        Button button = new Button(getApplicationContext());
        button.setText("BUTTON A VIEW TYPE");

        final ViewSwitcher viewSwitcher = (ViewSwitcher) findViewById(R.id.cx_viewswitcher);
        viewSwitcher.addView(imageView2);
        viewSwitcher.addView(button);
        Button vsnextbuton = (Button) findViewById(R.id.vsnext);
        Button vspreviousbutton = (Button) findViewById(R.id.vsprecious);
        vsnextbuton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewSwitcher.showNext();
            }
        });


        vspreviousbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewSwitcher.showPrevious();
            }
        });



        /*image switcher in android */
        final ImageSwitcher imageSwitcher = (ImageSwitcher) findViewById(R.id.cx_imageswitcher);
        imageSwitcher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageSwitcher.showNext();

            }
        });


        /*text switcher */
        final TextSwitcher textSwitcher=(TextSwitcher)findViewById(R.id.cx_textswitcher);
        textSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                return new TextView(getApplicationContext());
            }
        });

        textSwitcher.setText("Bonjour");
        textSwitcher.setText("Kon'nichiwa");
        textSwitcher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textSwitcher.showNext();
            }
        });


        /*adapter view flipper */
        AdapterViewFlipper adapterViewFlipper = (AdapterViewFlipper) findViewById(R.id.cx_adapterviewflipper);
        adapterViewFlipper.setAdapter(new componentslistadapter());
        adapterViewFlipper.setFlipInterval(5000);
        adapterViewFlipper.startFlipping();




        /* view stub*/
        /*ViewStub viewStub=(ViewStub)findViewById(R.id.cx_viewstub);
        viewStub.setVisibility(View.VISIBLE);*/





        /*stack view */
        StackView stackView = (StackView) findViewById(R.id.cx_stackview);
        ArrayList<Stackitem> arrayListitems = new ArrayList<Stackitem>();
        arrayListitems.add(new Stackitem(this.getResources().getDrawable(R.drawable.android)));
        arrayListitems.add(new Stackitem(this.getResources().getDrawable(R.drawable.images)));
        arrayListitems.add(new Stackitem(this.getResources().getDrawable(R.drawable.one)));
        arrayListitems.add(new Stackitem(this.getResources().getDrawable(R.drawable.two)));
        arrayListitems.add(new Stackitem(this.getResources().getDrawable(R.drawable.three)));
        Stackadapter stackadapter = new Stackadapter(this, R.layout.stackviewlayout, arrayListitems);

        stackView.setAdapter(stackadapter);


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 100:
                    Uri uri = data.getData();
                    FrameLayout frameLayout = (FrameLayout) findViewById(R.id.badge_framelayout);
                    frameLayout.setVisibility(View.VISIBLE);
                    QuickContactBadge badgelarge = new QuickContactBadge(getApplicationContext());
                    badgelarge.assignContactUri(uri);
                    badgelarge.setMode(ContactsContract.QuickContact.MODE_LARGE);
                    badgelarge.setImageResource(R.drawable.android);
                    frameLayout.addView(badgelarge);
                    break;
            }
        }
    }


}



    /*@Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.componentexplanation);
         System.out.println("component explanation");
        //Toast.makeText(Componentexplanation.this, "oncreate", Toast.LENGTH_SHORT).show();
        *//*Toast.makeText(Componentexplanation.this, "oncreate", Toast.LENGTH_SHORT).show();
        Bundle values=getIntent().getExtras();
        Integer position=values.getInt("positionvalue");
         if(position==null) {
             System.out.println("position " + position);
         }
        String ids=Specialcomponents.componentsname.get(position);
        int resourceid=getResources().getIdentifier(ids,null,null);

        System.out.println("resources id " + resourceid);

        LinearLayout linearLayout=(LinearLayout)findViewById(resourceid);
        linearLayout.setVisibility(View.VISIBLE);
*//*
    }*/

