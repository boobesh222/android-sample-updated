package com.example.boobeshb.expertcomponentsexample.classes;

import com.example.boobeshb.expertcomponentsexample.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by boobeshb on 03-05-2016.
 */
public class Specialcomponents {

    public static List<String> componentsname=new ArrayList<>();
    public static  List<Integer> componentId=new ArrayList<>();

     public static void addcomponents() {
        componentsname.add("space");
        componentsname.add("checked_textview");
        componentsname.add("quickcontact_badge");
        componentsname.add("Extract_edittext");
        componentsname.add("Autocomplete_textview");
        componentsname.add("Multi_autocomplete_textview");
        componentsname.add("numberpicker");
        componentsname.add("zoom_button");
        componentsname.add("zoom_controls");
        componentsname.add("Media_controller");
        componentsname.add("gesture_overlay_view");
        componentsname.add("surface_view");
        componentsname.add("texture_view ");
        componentsname.add("stack_view");
        componentsname.add("View_stub");
        componentsname.add("View_animator");
        componentsname.add("View_Flipper");
        componentsname.add("view_switcher");
        componentsname.add("image_switcher");
        componentsname.add("text_switcher");
        componentsname.add("Adapter_view_Flipper");
    }

   public static  void addcomponentId(){

      componentId.add(R.id.space);
      componentId.add(R.id.checked_textview);
      componentId.add(R.id.quickcontact_badge);
      componentId.add(R.id.Extract_edittext) ;
      componentId.add(R.id.Autocomplete_textview);
      componentId.add(R.id.Multi_autocomplete_textview);
      componentId.add(R.id.numberpicker);
      componentId.add(R.id.zoom_button);
      componentId.add(R.id.zoom_controls);
      componentId.add(R.id.Media_controller);
      componentId.add(R.id.gesture_overlay_view);
      componentId.add(1);
      componentId.add(1);
      componentId.add(R.id.stack_view);
      componentId.add(R.id.View_stub);
      componentId.add(R.id.View_animator);
      componentId.add(R.id.View_Flipper);
      componentId.add(R.id.view_switcher);
      componentId.add(R.id.image_switcher);
      componentId.add(R.id.text_switcher);
      componentId.add(R.id.Adapter_view_Flipper);

   }

}
