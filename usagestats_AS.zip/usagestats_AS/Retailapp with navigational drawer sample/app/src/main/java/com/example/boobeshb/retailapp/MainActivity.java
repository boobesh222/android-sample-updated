package com.example.boobeshb.retailapp;

import android.app.Fragment;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends ActionBarActivity {
    DrawerLayout drawerLayout;
    ListView drawerlistview;
    ActionBarDrawerToggle mdrawertoggle;

    CharSequence mDrawerTitle;
    CharSequence mTitle;

    String[] navmenutitles={"men","women","kids"};

    int[] navicons={R.drawable.men,R.drawable.women,R.drawable.kids};
    TypedArray navmenuicons;

    ArrayList<navdrawerclass> navdrawerlist;
    Navlistadapter navlistadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerTitle=mTitle=getTitle();
        navmenuicons=getResources().obtainTypedArray(R.array.nav_drawer_icons);
        drawerLayout=(DrawerLayout)findViewById(R.id.drawerlayout_main);
        drawerlistview=(ListView)findViewById(R.id.listview_main);
        System.out.println(navmenuicons.toString());
        navdrawerlist=new ArrayList<navdrawerclass>();
        navdrawerlist.add(new navdrawerclass(navmenutitles[0], navmenuicons.getResourceId(0, -1)));
        navdrawerlist.add(new navdrawerclass(navmenutitles[1],navmenuicons.getResourceId(1,-1)));
        navdrawerlist.add(new navdrawerclass(navmenutitles[2], navmenuicons.getResourceId(2, -1)));
        drawerlistview.setOnItemClickListener(new slideMenuClickListener());

        navmenuicons.recycle();

        navlistadapter=new Navlistadapter(getApplicationContext(),navdrawerlist);
        drawerlistview.setAdapter(navlistadapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mdrawertoggle=new ActionBarDrawerToggle(this,drawerLayout,R.string.draweropen,R.string.drawerclosed){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle(mTitle);
                // calling onPrepareOptionsMenu() to show action bar icons
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle(mDrawerTitle);
                // calling onPrepareOptionsMenu() to hide action bar icons
                invalidateOptionsMenu();
            }
        };



        drawerLayout.setDrawerListener(mdrawertoggle);

        if (savedInstanceState==null){
             displayview(0);
        }



    }

    private class slideMenuClickListener implements ListView.OnItemClickListener{
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            displayview(position);
        }
    }




    public void displayview(int position){
        Fragment fragment=null;
        switch (position){
            case 0:
                fragment=new Homefragment();
                break;
            case 1:
                fragment=new mensfragment();
                break;
            case 2:
                fragment=new kidsfrag();
            default:
                break;
        }

        if(fragment!=null){
            getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment,null).commit();
            drawerlistview.setItemChecked(position, true);
             drawerlistview.setSelection(position);
             setTitle(navmenutitles[position]);
            drawerLayout.closeDrawer(drawerlistview);
        }



    }

    @Override
    public void setTitle(CharSequence title) {
        mTitle=title;
        getSupportActionBar().setTitle(mTitle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        mdrawertoggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mdrawertoggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if(mdrawertoggle.onOptionsItemSelected(item)){

            return  true;
        }

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean drau=drawerLayout.isDrawerOpen(drawerlistview);
        menu.findItem(R.id.action_settings).setVisible(!drau);
        return super.onPrepareOptionsMenu(menu);


    }
}
