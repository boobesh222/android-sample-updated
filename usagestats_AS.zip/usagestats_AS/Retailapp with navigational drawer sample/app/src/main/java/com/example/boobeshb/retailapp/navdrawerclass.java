package com.example.boobeshb.retailapp;

/**
 * Created by boobeshb on 22-03-2016.
 */
public class navdrawerclass {


    public String title;
    public int icon;
    public String counter="0";
    public boolean countervisible=false;


    public navdrawerclass() {
    }

    public navdrawerclass(String title, int icon) {
        this.title = title;
        this.icon = icon;
    }


    public navdrawerclass(String title, int icon, String counter, boolean countervisible) {
        this.title = title;
        this.icon = icon;
        this.counter = counter;
        this.countervisible = countervisible;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public boolean isCountervisible() {
        return countervisible;
    }

    public void setCountervisible(boolean countervisible) {
        this.countervisible = countervisible;
    }


}
