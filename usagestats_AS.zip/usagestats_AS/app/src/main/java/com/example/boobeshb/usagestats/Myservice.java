package com.example.boobeshb.usagestats;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by boobeshb on 01-04-2016.
 */
public class Myservice extends Service {
     String  startedtime;
    int shour;
    int smin;
     long endtime;
    int ehour;
    int emin;
    Date starttime;
    Calendar cal=Calendar.getInstance();
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(Myservice.this, "SERVICE STARTED", Toast.LENGTH_SHORT);
        System.out.println(" ON START COMMAND");

        PackageManager pm=getPackageManager();
        List<PackageInfo> installedpackages=pm.getInstalledPackages(PackageManager.GET_META_DATA);
        for(PackageInfo p:installedpackages){
              System.out.println("info on packages" + p.packageName+ " receivers"+p.receivers);
        }

        Intent intents =getPackageManager().getLaunchIntentForPackage("com.example.boobeshb.xmlparsing");
        intents.addCategory(Intent.CATEGORY_LAUNCHER);
        Date date=new Date();
        shour=cal.get(Calendar.HOUR_OF_DAY);
        smin=cal.get(Calendar.MINUTE);
        startedtime=shour+":"+smin;
        starttime=cal.getTime();
        System.out.println("Started time " + startedtime+ cal.getTime()+"Date obj" );
        startActivity(intents);
        Timer timer=new Timer();
        timer.scheduleAtFixedRate(new checkrunnungapps(),new Date(),60000);


        return START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(Myservice.this, "SERVICE STOPPED", Toast.LENGTH_SHORT).show();
    }


    class checkrunnungapps extends TimerTask{
        ActivityManager  am=(ActivityManager)getSystemService(Myservice.this.ACTIVITY_SERVICE);

        @Override
        public void run() {


            List<ActivityManager.RunningAppProcessInfo> runningprocess=am.getRunningAppProcesses();
            System.out.println(runningprocess.get(0)+"RUNNING ACTIVITY");
            Boolean runningprocesses= runningprocess.equals("com.example.boobeshb.xmlparsing");
            System.out.println("running or not " + runningprocess);
            for(ActivityManager.RunningAppProcessInfo r:runningprocess){
                System.out.println("FOR LOOP  " + r.processName);

                Calendar calendar=Calendar.getInstance();

                if(r.processName.equals("com.example.boobeshb.xmlparsing")){
                    System.out.println(" YOUR APP RUNNING ");
                }else if(r.processName != "com.example.boobeshb.xmlparsing"){
                    ehour= calendar.get(Calendar.HOUR_OF_DAY);
                    emin=calendar.get(Calendar.MINUTE);
                    System.out.println(shour+":"+smin);
                    System.out.println(ehour+":"+emin);
                    System.out.println(calendar.getTime());
                    Date endtime=calendar.getTime();
                    long diff =endtime.getTime()-starttime.getTime();
                    long diffSeconds = diff / 1000 % 60;
                    long diffMinutes = diff / (60 * 1000) % 60;
                    long diffHours = diff / (60 * 60 * 1000) % 24;
                    long diffDays = diff / (24 * 60 * 60 * 1000);
                    System.out.println("ELAPSED TIME SINCE STARTED" + "  " + (ehour - shour) + ":" + (emin - smin));
                    System.out.println(diffDays + "  days  " +diffHours+"  hours  "+diffMinutes+"  minutes  "+diffSeconds +"  seconds  "+ "date object new calculation ");

                }

            }

        }
    }
}
