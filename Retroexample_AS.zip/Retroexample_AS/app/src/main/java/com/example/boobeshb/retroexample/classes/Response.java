package com.example.boobeshb.retroexample.classes;

/**
 * Created by boobeshb on 03-06-2016.
 */
public class Response {

    public Double lat;
    public int mallId;
    public Double longi;

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public int getMallId() {
        return mallId;
    }

    public void setMallId(int mallId) {
        this.mallId = mallId;
    }

    public Double getLongi() {
        return longi;
    }

    public void setLongi(Double longi) {
        this.longi = longi;
    }
}
