package com.example.boobeshb.retroexample.classes;

import android.os.AsyncTask;

import org.json.JSONObject;

/**
 * Created by boobeshb on 03-06-2016.
 */
public class fetch extends AsyncTask<String,String,JSONObject> {
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(JSONObject jsonObject) {
        super.onPostExecute(jsonObject);
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected JSONObject doInBackground(String... params) {
        return null;
    }
}
