package com.example.boobeshb.retroexample.classes;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 24-03-2016.
 */
public class JSONparse extends AsyncTask<String, String, JSONObject> {

    String Url = "http://www.json-generator.com/api/json/get/bOqXMBgzAO?indent=2";



    Context context;
    public JSONparse(Context c) {
     context=c;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }


    @Override
    protected JSONObject doInBackground(String... params) {
        Jsonparser parser = new Jsonparser();
        JSONObject object = parser.getJSONfromURL(Url);
        return object;
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(JSONObject jsonObject) {
        super.onPostExecute(jsonObject);
        List<Response> response=new ArrayList<>();

        JSONObject jo=jsonObject;
        try{
           JSONArray ja= jo.getJSONArray("locations");

            for(int i=0;i<ja.length();i++){
                Response res=new Response();
                JSONObject jo1= new JSONObject();
                          jo1=ja.getJSONObject(i);

                res.setMallId(jo1.getInt("mallId"));
                res.setLat(jo1.getDouble("lat"));
                res.setLongi(jo1.getDouble("longitude"));
                response.add(res);
                System.out.println(jo1.getDouble("lat")+  "   "  + jo1.getDouble("longitude"));
            }
        }catch(JSONException E){
            E.printStackTrace();
        }
        for(Response s:response){
            System.out.println("LIST VALUES"+ "mallid" + s.getMallId()+ " " +s.getLongi()+" " + s.getLat() );
        }

    }

}
