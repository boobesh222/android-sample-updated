package com.example.boobeshb.retroexample.interfaces;

import com.example.boobeshb.retroexample.classes.Category;
import com.example.boobeshb.retroexample.classes.Curator;
import com.example.boobeshb.retroexample.classes.Response;
import com.example.boobeshb.retroexample.classes.Sample;
import com.example.boobeshb.retroexample.classes.Vehicles;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by boobeshb on 26-04-2016.
 */
public interface VehicleService {

    @GET("json/{method}/clpAoZdxlu")
    Call<List<Sample>> getVehicles(@Path("method")String method,@Query("indent") int number);

    @GET("json/{method}/cjnOnqcahu?indent=2")
    Call<List<Response>> getCategories(@Path("method")String method);

}
