package com.example.boobeshb.retroexample.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.boobeshb.retroexample.R;
import com.example.boobeshb.retroexample.classes.Category;
import com.example.boobeshb.retroexample.classes.Sample;

/**
 * Created by boobeshb on 27-04-2016.
 */
public class Listadapters extends BaseAdapter {

    @Override
    public int getCount() {
        return Category.categorylist.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.listviewlayout,null);
        TextView tv=(TextView)v.findViewById(R.id.listviewtextfields);
        tv.setText(Category.categorylist.get(position));
        return  v;
    }
}
