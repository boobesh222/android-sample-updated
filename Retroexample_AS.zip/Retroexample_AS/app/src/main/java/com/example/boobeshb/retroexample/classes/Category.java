package com.example.boobeshb.retroexample.classes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 02-05-2016.
 */
public class Category {

    public String category;
    public static List<String> categorylist=new ArrayList<String>();


    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
