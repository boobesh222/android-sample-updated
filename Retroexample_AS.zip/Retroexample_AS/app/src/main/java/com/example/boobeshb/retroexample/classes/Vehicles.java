package com.example.boobeshb.retroexample.classes;

import android.graphics.Color;

import java.util.concurrent.locks.Condition;

/**
 * Created by boobeshb on 26-04-2016.
 */
public class Vehicles  {

     private String make;
     private String model;
     private Color colour;
     private  int year;
     private Condition condition;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Color getColour() {
        return colour;
    }

    public void setColour(Color colour) {
        this.colour = colour;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Condition getCondition() {
        return condition;
    }

    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    @Override
    public String toString() {
        return "Vehicles{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", colour=" + colour +
                ", year=" + year +
                ", condition=" + condition +
                '}';
    }
}
