package com.example.boobeshb.retroexample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.style.ReplacementSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.boobeshb.retroexample.R;
import com.example.boobeshb.retroexample.adapters.Listadapters;
import com.example.boobeshb.retroexample.classes.Category;
import com.example.boobeshb.retroexample.classes.JSONparse;
import com.example.boobeshb.retroexample.classes.Response;
import com.example.boobeshb.retroexample.classes.Curator;
import com.example.boobeshb.retroexample.classes.Sample;
import com.example.boobeshb.retroexample.classes.Vehicles;
import com.example.boobeshb.retroexample.interfaces.VehicleService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends ActionBarActivity {
    private static final String API_KEY = "-------";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


/*
http://192.168.18.70/sasi/saishreeillam/expense_category.json
        http://www.json-generator.com/api/json/get/clpAoZdxlu?indent=2
*/
/*http://www.json-generator.com/api/json/get/cpvRnsMwXS?indent=2
        http://www.json-generator.com/api/json/get/bOYqzbaoJe?indent=2
*/
/*
        http://www.json-generator.com/api/json/get/coSkWmDoMO?indent=2
*/
         /* creating rest adapter*/
//        http://www.json-generator.com/api/json/get/bPLTlSDFOW?indent=2

        /*new */
        /*http://www.json-generator.com/api/json/get/cjnOnqcahu?indent=2*/

   /*http://www.json-generator.com/api/json/get/bOqXMBgzAO?indent=2*/
        Button button=(Button)findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*new JSONparse(getApplicationContext()).execute();
                */


                final Retrofit adapter = new Retrofit.Builder().baseUrl("http://www.json-generator.com/api/").addConverterFactory(GsonConverterFactory.create()).build();
         /*creating interface instance*/
                VehicleService vehicleInterface = adapter.create(VehicleService.class);
                System.out.println("response above call" );

                String method = "get";
                Call<List<Response>> call = vehicleInterface.getCategories(method);
                System.out.println("called "+call.isExecuted());
                call.enqueue(new Callback<List<Response>>() {

                   @Override
                   public void onResponse(Call<List<Response>> call, retrofit2.Response<List<Response>> response) {
                       System.out.println("On response ");

                       for(int i=0;i<response.body().size();i++){
                           System.out.println("response" + response.toString());
                           Toast.makeText(MainActivity.this, " response" + response.toString(), Toast.LENGTH_SHORT).show();
                       }

                   }

                   @Override
                   public void onFailure(Call<List<Response>> call, Throwable t) {
                       System.out.println("response failure" +call.request() );
                   }
               });



            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
