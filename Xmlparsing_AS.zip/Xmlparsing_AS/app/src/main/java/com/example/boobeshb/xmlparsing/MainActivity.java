package com.example.boobeshb.xmlparsing;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

public class MainActivity extends ActionBarActivity {
    TextView view1,view2,view3,view4;
    EditText editText;

    private String url1 = "http://api.openweathermap.org/data/2.5/weather?q=";
    private String url2 = "&mode=xml";
    private Handlexml obj;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);

        view1=(TextView)findViewById(R.id.textviewone);
        view2=(TextView)findViewById(R.id.textviewtwo);
        view3=(TextView)findViewById(R.id.textviewthree);
        view4=(TextView)findViewById(R.id.textviewfour);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



               obj=new Handlexml();
               Map values=obj.fetchxml(getBaseContext());

                Toast.makeText(MainActivity.this,""+ values, Toast.LENGTH_LONG).show();


            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}



/*@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);

        view1=(TextView)findViewById(R.id.textviewone);
        view2=(TextView)findViewById(R.id.textviewtwo);
        view3=(TextView)findViewById(R.id.textviewthree);
        view4=(TextView)findViewById(R.id.textviewfour);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



               obj=new Handlexml();
               obj.fetchxml();

                while (obj.parsingcomplete){
                    view1.setText(obj.getCountry());
                    view2.setText(obj.getHumidity());
                    view3.setText(obj.getTemperature());
                    view4.setText(obj.getPressure());

                }
            }
        });

    }*/