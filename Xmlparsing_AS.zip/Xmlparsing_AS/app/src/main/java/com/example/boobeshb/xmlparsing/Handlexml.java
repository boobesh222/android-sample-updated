package com.example.boobeshb.xmlparsing;

import android.content.Context;
import android.content.res.AssetManager;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by boobeshb on 14-03-2016.
 */
public class Handlexml  {


    String country;
    String humidity;
    String pressure;
    String temperature;
    String url =null;
    XmlPullParserFactory parserFactory;
    boolean parsingcomplete=true;
    Map a=new HashMap();


    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getPressure() {
        return pressure;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temparature) {
        this.temperature = temperature;
    }

    public Map  fetchxml(Context c){
       final Context con=c;

        AssetManager   am=con.getAssets();

        try{
            InputStream inputStream=am.open("qrcode.xml");
            parserFactory=XmlPullParserFactory.newInstance();
            XmlPullParser parser=parserFactory.newPullParser();
            parser.setFeature(parser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);
            a=  parsingxml(parser);
            System.out.println("Aadhar card values" +a);
            inputStream.close();
            return  a;
        }catch (MalformedURLException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }catch (XmlPullParserException e){
            e.printStackTrace();
        }

        return  a;
        /*Thread thread=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    *//*URL urlobject = new URL(" http://www.androidpeople.com/wp-content/uploads/2010/06/example.xml");
                    HttpURLConnection httpURLConnection= (HttpURLConnection)urlobject.openConnection();
                    httpURLConnection.setReadTimeout(100000);
                    httpURLConnection.setConnectTimeout(100000);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.connect();*//*
                       AssetManager   am=con.getAssets();

                    *//*InputStream is=httpURLConnection.getInputStream();*//*
                    InputStream inputStream=am.open("qrcode.xml");
                    parserFactory=XmlPullParserFactory.newInstance();
                    XmlPullParser parser=parserFactory.newPullParser();
                    parser.setFeature(parser.FEATURE_PROCESS_NAMESPACES, false);
                    parser.setInput(inputStream, null);
                    a=  parsingxml(parser);
                    System.out.println("Aadhar card values" +a);
                    inputStream.close();

                }catch (MalformedURLException e){
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }catch (XmlPullParserException e){
                    e.printStackTrace();
                }

            }

        });
        thread.start();*/




    }

    public Map parsingxml(XmlPullParser parser){
        List<String> values=new ArrayList<String>();
        Map qrvalues=new HashMap();
        int event;
        String text=null;

           try {
               event= parser.getEventType();
               while (event != XmlPullParser.END_DOCUMENT){
                   String name=parser.getName();//did'nt understand


                   System.out.println("WHILE LOOP PARSING XML " + parser.getAttributeCount() + "ATTRIBUTE COUNT");
                   switch (event){
                       case XmlPullParser.START_TAG:
                           System.out.println("case 1");
                           String names=parser.getName();
                           System.out.println("COUNT " +parser.getAttributeCount()+"NAMES "+names);
                           for (int i=0 ;i<parser.getAttributeCount();i++){
                               String attributenames=parser.getAttributeName(i);
                              /* System.out.println("ATTRIBUTE NAMES"+attributenames);*/
                               String attributevalues= parser.getAttributeValue(null,attributenames);
                              /* System.out.println(attributevalues);*/
                               qrvalues.put(attributenames,attributevalues);
                           }
                           break;
                       case XmlPullParser.TEXT:
                           break;
                       case XmlPullParser.END_TAG:
                           break;
                   }
                   event=parser.next();
               }
               parsingcomplete = false;
               values.add(humidity);
               values.add(text);
           }catch (XmlPullParserException e){
               e.printStackTrace();
           }catch (IOException e){
               e.printStackTrace();
           }
        return qrvalues;

    }

}



/* public List<String> parsingxml(XmlPullParser parser){
        List<String> values=new ArrayList<String>();
        int event;
        String text=null;

           try {
               event= parser.getEventType();
               while (event != XmlPullParser.END_DOCUMENT){
                   String name=parser.getName();//did'nt understand
                   parser.getAttributeCount();

                   System.out.println("WHILE LOOP PARSING XML "+ parser.getAttributeCount()+"ATTRIBUTE COUNT");
                   switch (event){
                       case XmlPullParser.START_TAG:
                           System.out.println("case 1");
                           humidity = parser.getAttributeValue(null,"category");
                           System.out.println("COUNT " +parser.getAttributeCount()+humidity);
                           break;
                       case XmlPullParser.TEXT:
                           text=parser.getText();
                           System.out.println("case 2");
                           break;
                       case XmlPullParser.END_TAG:
                           if(name.equals("website")){
                               country=text;
                               System.out.println(country + "IF LOOP" + humidity+"COUNT " +parser.getAttributeCount());
                           }else if (name.equals("name")){
                               temperature = text;

                               System.out.println(text + "text ");
                           }
                           System.out.println("case 3");
                           break;
                   }
                   event=parser.next();
               }
               parsingcomplete = false;
               values.add(humidity);
               values.add(text);
           }catch (XmlPullParserException e){
               e.printStackTrace();
           }catch (IOException e){
               e.printStackTrace();
           }
        return values;

    }*/


/* public Map  fetchxml(Context c){
       final Context con=c;
        Thread thread=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    /*URL urlobject = new URL(" http://www.androidpeople.com/wp-content/uploads/2010/06/example.xml");
                    HttpURLConnection httpURLConnection= (HttpURLConnection)urlobject.openConnection();
                    httpURLConnection.setReadTimeout(100000);
                    httpURLConnection.setConnectTimeout(100000);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.connect();
AssetManager   am=con.getAssets();

InputStream is=httpURLConnection.getInputStream();
InputStream inputStream=am.open("qrcode.xml");
parserFactory=XmlPullParserFactory.newInstance();
        XmlPullParser parser=parserFactory.newPullParser();
        parser.setFeature(parser.FEATURE_PROCESS_NAMESPACES, false);
        parser.setInput(inputStream, null);
        a=  parsingxml(parser);
        System.out.println("Aadhar card values" +a);
        inputStream.close();

        }catch (MalformedURLException e){
        e.printStackTrace();
        }catch (IOException e){
        e.printStackTrace();
        }catch (XmlPullParserException e){
        e.printStackTrace();
        }

        }

        });
        thread.start();

        return a;*/



