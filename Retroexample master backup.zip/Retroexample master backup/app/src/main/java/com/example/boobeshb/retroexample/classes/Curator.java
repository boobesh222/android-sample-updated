package com.example.boobeshb.retroexample.classes;

import java.util.List;

/**
 * Created by boobeshb on 27-04-2016.
 */
public class Curator {
   private  String title;
    public List<Dataset> dataset;

    public  class Dataset{
        String curator_title;
        String curator_tagline;
    }

}
