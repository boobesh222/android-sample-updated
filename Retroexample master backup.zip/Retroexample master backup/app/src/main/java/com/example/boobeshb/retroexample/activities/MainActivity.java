package com.example.boobeshb.retroexample.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.style.ReplacementSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.boobeshb.retroexample.R;
import com.example.boobeshb.retroexample.adapters.Listadapters;
import com.example.boobeshb.retroexample.classes.Curator;
import com.example.boobeshb.retroexample.classes.Sample;
import com.example.boobeshb.retroexample.classes.Vehicles;
import com.example.boobeshb.retroexample.interfaces.VehicleService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends ActionBarActivity {
    private static final String API_KEY = "-------";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


/*
        http://www.json-generator.com/api/json/get/clpAoZdxlu?indent=2
*/
/*http://www.json-generator.com/api/json/get/cpvRnsMwXS?indent=2
        http://www.json-generator.com/api/json/get/bOYqzbaoJe?indent=2
*/
/*
        http://www.json-generator.com/api/json/get/coSkWmDoMO?indent=2
*/
         /* creating rest adapter*/
//        http://www.json-generator.com/api/json/get/bPLTlSDFOW?indent=2

        Button button=(Button)findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Retrofit adapter = new Retrofit.Builder().baseUrl("http://www.json-generator.com/api/").addConverterFactory(GsonConverterFactory.create()).build();
         /*creating interface instance*/
                VehicleService vehicleInterface = adapter.create(VehicleService.class);
                int a = 2;
                String method = "get";
                Call<List<Sample>> call = vehicleInterface.getVehicles(method, a);
                call.enqueue(new Callback<List<Sample>>() {

                    @Override
                    public void onResponse(Call<List<Sample>> call, Response<List<Sample>> response) {
                        System.out.println("RESPONSE LENGTH" + response.body().size() + response.body().get(0).getFathername() + " location 2 ");
                        List<Sample> sampleList = new ArrayList<Sample>();
                        for (int i = 0; i < response.body().size(); i++) {
                            sampleList = response.body();
                            System.out.println(sampleList.get(i).getName() + sampleList.get(i).getFathername() + sampleList.get(i).getNationality() + sampleList.get(i).getAge() + sampleList.get(i).getSex());
                            Sample.namelist.add(sampleList.get(i).getName());
                            Sample.fathernamelist.add(sampleList.get(i).getFathername());
                            Sample.agelist.add(sampleList.get(i).getAge());
                            Sample.Nationalitylist.add(sampleList.get(i).getNationality());
                            Sample.listsex.add(sampleList.get(i).getSex());

                            /*for (Sample s : sampleList) {
                                *//*TextView one=(TextView)findViewById(R.id.one);
                                TextView two=(TextView)findViewById(R.id.two);

                                TextView three=(TextView)findViewById(R.id.three);

                                TextView four=(TextView)findViewById(R.id.foursdfy);

                                TextView five=(TextView)findViewById(R.id.five);
                                one.setText(s.getName());
                                two.setText(s.getFathername());
                                three.setText(s.getNationality());
                                //four.setText(s.getAge());
                                five.setText(s.getSex());*//*
                            }*/
                        }
                        ListView lv = (ListView) findViewById(R.id.list_item);
                        lv.setAdapter(new Listadapters());
                        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Intent i = new Intent(getApplicationContext(), detailedactivity.class);
                                i.putExtra("position", position);
                                startActivity(i);
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<List<Sample>> call, Throwable t) {
                        t.printStackTrace();
                    }
                });

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
