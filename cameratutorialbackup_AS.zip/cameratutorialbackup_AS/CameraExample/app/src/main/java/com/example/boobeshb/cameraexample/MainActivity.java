package com.example.boobeshb.cameraexample;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends ActionBarActivity {

    Uri fileuri;
    public static final int MEDIA_TYPE_IMAGE=1;

    public static final int MEDIA_TYPE_VIDEO=2;
    ImageView captturedimage;
    VideoView recordedvideo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button captureImage=(Button)findViewById(R.id.image);
        Button recordVideo=(Button)findViewById(R.id.video);
        captturedimage=(ImageView)findViewById(R.id.capturedimage);
        recordedvideo=(VideoView)findViewById(R.id.videoview);
        captureImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        recordVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recordlivevideo();
            }
        });
    }

    public void captureImage(){
        Intent intent =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        fileuri=getoutputmediauri(MEDIA_TYPE_IMAGE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileuri);
        startActivityForResult(intent, 100);
    }

   public void recordlivevideo(){
       Intent intent=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
       fileuri=getoutputmediauri(MEDIA_TYPE_VIDEO);
       intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1);
       intent.putExtra(MediaStore.EXTRA_OUTPUT,fileuri);
       startActivityForResult(intent,200);
   }

    public Uri getoutputmediauri(int type){

        return  Uri.fromFile(getFile(type));
    }

    public static File getFile(int type){

        File mediastoragedirectory=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),"hellocamera");

        if(!mediastoragedirectory.exists()){
            if(!mediastoragedirectory.mkdirs()){
                System.out.println("CREATING DIRECTORY FAILED");
                return null;
            }
        }


        String timeformat=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
       File Mediafile;

        if(type==MEDIA_TYPE_IMAGE){
              Mediafile=new File(mediastoragedirectory,"Image"+".jpg");
            try{
                FileOutputStream outstream=new FileOutputStream(Mediafile);
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }else if(type==MEDIA_TYPE_VIDEO){
            Mediafile=new File(mediastoragedirectory,"video"+timeformat);
        }else{
            return null;
        }
        System.out.println("FILE PATH" + Mediafile.getAbsolutePath());
        return Mediafile;
    }

    public void previewCapturedImage(){
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inSampleSize=8;
        Bitmap bitmap= BitmapFactory.decodeFile(fileuri.getPath(),options);
        captturedimage.setImageBitmap(bitmap);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==100){
            if(resultCode== RESULT_OK){
                System.out.println("RESULT CODE " + 100);
                /*new data for croping */
               // performcrop();
                /*end of cropping data */
                //previewCapturedImage();
            }else if(resultCode==RESULT_CANCELED){
                Toast.makeText(MainActivity.this, " USER CANCELLED CAMERA OPERATION", Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode==200){
            if(resultCode== RESULT_OK){


            }else if(resultCode==RESULT_CANCELED){
                Toast.makeText(MainActivity.this, " USER CANCELLED VIDEO OPERATION", Toast.LENGTH_SHORT).show();
            }
        }/*else if(requestCode==2){
            Bundle extras = data.getExtras();
            Bitmap images = extras.getParcelable("data");
            captturedimage.setImageBitmap(images);
        }*/

    }

    /*public void performcrop() {
        System.out.println("inside perform crop ");
        Intent intent = new Intent("com.android.camera.action.crop");
        intent.setDataAndType(fileuri, "image*//*");
        intent.putExtra("aspectX", 2);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 2);


    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
