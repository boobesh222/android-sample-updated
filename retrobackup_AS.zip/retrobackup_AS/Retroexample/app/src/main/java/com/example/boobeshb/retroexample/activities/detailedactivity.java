package com.example.boobeshb.retroexample.activities;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.boobeshb.retroexample.R;
import com.example.boobeshb.retroexample.classes.Sample;

/**
 * Created by boobeshb on 27-04-2016.
 */
public class detailedactivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detailedviewlayout);
        Bundle b=getIntent().getExtras();
        b.getInt("position");
        TextView one=(TextView)findViewById(R.id.one);
       // TextView two=(TextView)findViewById(R.id.two);
        TextView three=(TextView)findViewById(R.id.three);
        TextView four=(TextView)findViewById(R.id.four);
        TextView five=(TextView)findViewById(R.id.five);
        one.setText(Sample.namelist.get(b.getInt("position")));
        //two.setText(Sample.agelist.get(b.getInt("position")));
        three.setText(Sample.fathernamelist.get(b.getInt("position")));
        four.setText(Sample.listsex.get(b.getInt("position")));
        five.setText(Sample.Nationalitylist.get(b.getInt("position")));
    }
}
