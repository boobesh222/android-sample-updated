package com.example.boobeshb.retroexample.interfaces;

import com.example.boobeshb.retroexample.classes.Curator;
//import com.example.boobeshb.retroexample.classes.Getcoordinates;
import com.example.boobeshb.retroexample.classes.Details;
import com.example.boobeshb.retroexample.classes.Sample;
import com.example.boobeshb.retroexample.classes.Vehicles;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by boobeshb on 26-04-2016.
 */
public interface VehicleService {

   /* @GET("json/{method}/clpAoZdxlu")
    Call<List<Sample>> getVehicles(@Path("method")String method,@Query("indent") int number);
*/


    @GET("json/{method}/cozlxiCLkO")
    Call<Details> getVehicles(@Path("method")String method,@Query("indent") int number);


    @GET("Naveen/json/locationbasedoffers.json")
    Call<Details>  getLatLong();

}
