package com.example.boobeshb.retroexample.classes;

/**
 * Created by boobeshb on 06-06-2016.
 */
public class locations {
    public double lat;
    public double longitude;
    public int mallid;

}
