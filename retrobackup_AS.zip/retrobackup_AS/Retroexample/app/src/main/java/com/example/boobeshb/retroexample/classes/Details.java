package com.example.boobeshb.retroexample.classes;

import java.util.List;
import com.google.*;
/**
 * Created by boobeshb on 06-06-2016.
 */
public class Details {

    public List<locations> locations;

 }
