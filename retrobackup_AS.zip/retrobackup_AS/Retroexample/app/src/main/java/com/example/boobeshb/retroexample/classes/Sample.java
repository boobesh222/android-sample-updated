package com.example.boobeshb.retroexample.classes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 27-04-2016.
 */
public class Sample {

    public String name;
    public int age;
    public String sex;
    public String Nationality;
    public String fathername;
    public static List<Integer> agelist=new ArrayList<>();
    public static  List<String> listsex=new ArrayList<>();
    public static List<String> Nationalitylist=new ArrayList<>();
    public static List<String> fathernamelist=new ArrayList<>();
    public static  List<String> namelist=new ArrayList<>();


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String nationality) {
        Nationality = nationality;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

}


