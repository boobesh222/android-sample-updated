package com.example.boobeshb.notificationexample;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by boobeshb on 10-05-2016.
 */
public class Notificationview extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notificationview);

    }
}
