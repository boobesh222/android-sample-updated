package com.example.boobeshb.jsonparser;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends ActionBarActivity {

    TextView one;
    TextView two;
    TextView three;
    Button getdata;
    String Url="http://demo.codeofaninja.com/tutorials/json-example-with-php/index.php";
    public static final String taguser="Users";
    /*public static final String tagid="id";
    public static final String  tagemail="email";
    public static final String   tagname="tagname";*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getdata=(Button)findViewById(R.id.getdata);
        getdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  new JSONparse().execute();
            }
        });
    }

    public class JSONparse extends AsyncTask<String ,String,JSONObject>{
        ProgressDialog prgdialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
             one=(TextView)findViewById(R.id.textviewone);
             two=(TextView)findViewById(R.id.textviewtwo);
             three=(TextView)findViewById(R.id.textviewthree);
            prgdialog=new ProgressDialog(MainActivity.this,ProgressDialog.STYLE_SPINNER);
            prgdialog.setMessage("Getting data.....");
            prgdialog.setIndeterminate(false);
            prgdialog.setCancelable(true);
            prgdialog.show();
        }


        @Override
        protected JSONObject doInBackground(String... params) {
            Jsonparser parser=new Jsonparser();
            JSONObject object=parser.getJSONfromURL(Url);
            return  object;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);
            prgdialog.dismiss();
            JSONArray user;
            try{
                user=jsonObject.getJSONArray(taguser);

                JSONObject values=user.getJSONObject(8);
                String email=values.getString("firstname");
                String id=values.getString("lastname");
                String name=values.getString("username");
                one.setText(email);
                two.setText(id);
                three.setText(name);

            }catch (JSONException e){
                e.printStackTrace();
            }

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
