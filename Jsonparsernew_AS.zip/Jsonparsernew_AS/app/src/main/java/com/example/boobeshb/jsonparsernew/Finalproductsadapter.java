package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Created by boobeshb on 10-03-2016.
 */
public class Finalproductsadapter  extends BaseAdapter {
    public  static List<Bitmap> images=new ArrayList<Bitmap>();
    public  static  List<Integer> pricelist=new ArrayList<Integer>();
    public  static  List<String> sizelist=new ArrayList<String>();
    Context context;
    public Finalproductsadapter(List<Bitmap> bitmapList,Context c,List<Integer> p,List<String> s) {

        images=bitmapList;
        context=c;
        pricelist=p;
        sizelist=s;
        System.out.println("Images list SIZE" +images.size());

        for (int i=0;i<pricelist.size();i++){
            System.out.println("sizes " + pricelist.get(i)+"    "+sizelist.get(i));
        }

    }

    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater lyi=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflatedview=lyi.inflate(R.layout.imagelayout, null);
        ImageView imageview=(ImageView)inflatedview.findViewById(R.id.imagelayout_imageview);
        TextView price =(TextView)inflatedview.findViewById(R.id.price);
        TextView size=(TextView)inflatedview.findViewById(R.id.size);
        imageview.setImageBitmap(images.get(position));
        price.setText("INR " + pricelist.get(position));

        size.setText(sizelist.get(position));
        return  inflatedview;
    }
}
