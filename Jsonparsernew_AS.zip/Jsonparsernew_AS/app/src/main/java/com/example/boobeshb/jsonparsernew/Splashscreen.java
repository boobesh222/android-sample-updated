package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

/**
 * Created by boobeshb on 24-03-2016.
 */
public class Splashscreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);

             new JSONparse(Splashscreen.this).execute();


    }


    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    public void onBackPressed() {

        /*int count=getFragmentManager().getBackStackEntryCount();
            Toast.makeText(slideractivity.this, "position is "+count, Toast.LENGTH_SHORT).show();

            if(count ==0)
            {
                    super.onBackPressed();
                }else
            {
                    getFragmentManager().popBackStackImmediate();
                }
*/


    }

}
/*else if(count == 1 ) {
            getFragmentManager().popBackStack(2, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            final Dialog dialog=new Dialog(Splashscreen.this);
            dialog.setContentView(R.layout.dialogbox);
            dialog.setTitle("confirm !");
            dialog.show();
            Button b=(Button)dialog.findViewById(R.id.yesbutton);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();
                    Splashscreen.this.finish();
                }
            });
        }*/