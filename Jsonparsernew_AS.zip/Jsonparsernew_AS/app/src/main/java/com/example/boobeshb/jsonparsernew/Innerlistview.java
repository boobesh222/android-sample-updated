package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 07-03-2016.
 */
public class Innerlistview extends BaseAdapter {
    Context c;
    List<String> detailedList = new ArrayList<String>();
    String finalcontents[];
    String pre[] = new String[]{};

    public Innerlistview(Context context, List<String> list) {

        detailedList = list;
        c = context;
        System.out.println("CONSTRUCTOR");
        for (String s:detailedList){
            System.out.println("detailed list "+ s);
        }
        finalcontents = detailedList.toArray(pre);
        System.out.println(finalcontents);
    }

    @Override
    public int getCount() {
        System.out.println("detailedList.size()"+detailedList.size());
        return detailedList.size();
    }

    @Override
    public Object getItem(int position) {
        System.out.println("CONSTRUCTOR");
        return null;
    }

    @Override
    public long getItemId(int position) {
        System.out.println("CONSTRUCTOR");
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        System.out.println("CONTENTS" + finalcontents[position]);
        LayoutInflater ly=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v=ly.inflate(R.layout.simpletextview,null);
        System.out.println("B4 TEXT VIEW");
        TextView TView=(TextView)v.findViewById(R.id.textview_simpletext);
        System.out.println("CONTENTS" + finalcontents[position]);
        TView.setText(finalcontents[position]);
        return v;
    }
}