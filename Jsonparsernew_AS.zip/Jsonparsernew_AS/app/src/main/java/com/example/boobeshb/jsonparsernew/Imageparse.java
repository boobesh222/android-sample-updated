package com.example.boobeshb.jsonparsernew;

import android.animation.BidirectionalTypeConverter;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 28-03-2016.
 */
public class Imageparse extends AsyncTask<String, String, List<Bitmap> > {

    ProgressDialog prgdialog;
    Context c;

    public Imageparse(Context context) {
        c = context;
        System.out.println("IMAGE PARSE CONSTRUCTOR ");
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

       /* prgdialog = new ProgressDialog(c, ProgressDialog.STYLE_SPINNER);
        prgdialog.setMessage("Getting data.....");
        prgdialog.setIndeterminate(false);
        prgdialog.setCancelable(true);
        prgdialog.show();*/

    }

    @Override
    protected List<Bitmap> doInBackground(String... params) {
        Imageparser ip = new Imageparser();
        System.out.println(Retailappmodel.image.size() + "IMAGE SIZE  do in background");
        List<String> as = new ArrayList<String>();
        List<Bitmap> array = new ArrayList<Bitmap>();
        Retailappmodel.bitmapimages.clear();

        array.clear();
           /* image.clear();*/
        // as.add("https://i.imgsafe.org/5cbde6d.png");
        as.add("http://t86.imgup.net/eyewearea04.png");
           /* as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
            as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
            as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
*/
        // as.add("https://www.learn2crack.com/wp-content/uploads/2014/04/node-cover-720x340.png");                   ;
            /*Bitmap  s=ip.getJSONfromURL(as.get(0));
            s.toString();
            System.out.println("BITMAP HEIGHT " + s.getHeight() + s.getWidth()+s.getConfig());
            imagesarraybitmap.add(ip.getJSONfromURL(as.get(0)));
            System.out.println("IMAGES ARRAY BITMAP " + "" + imagesarraybitmap.size());*/
        for (int i = 0; i < Retailappmodel.image.size(); i++) {
           /* System.out.println("URL FOR VERIFIVCATION " + Retailappmodel.image.get(i));
            Bitmap  s=ip.getJSONfromURL( Retailappmodel.image.get(i));
            s.toString();
            System.out.println("BITMAP HEIGHT " + s.getHeight() + s.getWidth() + s.getConfig());*/
            array.add(ip.getJSONfromURL(Retailappmodel.image.get(i)));

        }

        System.out.println("IMAGES ARRAY BITMAP" + "" + array.size() + "    ");
        for(Bitmap s:array){
            System.out.println(s.toString()+ "for loop bitmaps ");
        }

        Retailappmodel.bitmapimages=array;
        System.out.println(Retailappmodel.bitmapimages.size()+"BIT MAPS SIZE DO IN BACKGROUND ");
        return array;
    }


    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(List<Bitmap> bitmaps) {
         super.onPostExecute(bitmaps);

         /*prgdialog.dismiss();*/
/*
         Retailappmodel.bitmapimages=bitmaps;
*/
         System.out.println("IMAGEPARSE ON POST EXECUTE" +bitmaps.size()+ "   " +Retailappmodel.bitmapimages.size());
        System.out.println("ARRAY LIST SIZE " + Retailappmodel.bitmapimages.size());


        /*System.out.println("ON POST EXECUTE");
        List<Bitmap> parsedimages=new ArrayList<Bitmap>();
        System.out.println("AFTER POST EXECUTE bitmap size" + bitmaps.size());
        parsedimages=bitmaps;

        // fgj.processresult(parsedimages);

            *//*

            Fragment test=new listviewFrag();

            System.out.println("GETTING FRAGMENT MANAGER");

            getFragmentManager().beginTransaction().replace(R.id.framelayouttwo,test,null).commit();

            View v=test.getView();
            System.out.println(test.isVisible()+"IS VISIBLE "+test.isAdded()+test.isInLayout());*//*
*//*
            lvv=(ListView)test.getView().findViewById(R.id.listview_generic);
*//*
        System.out.println("AFTER POST EXECUTE" + parsedimages.size());
        images(parsedimages);
        lv.setAdapter(new Customadapter(MainActivity.this, category, category.size(), parsedimages));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    *//*Intent nextpage = new Intent(getApplicationContext(), Nextpage.class);
                    //System.out.println("POSITION VALUE " + position+category.get(0) +"things at location ");
                    nextpageclass = new Nextpage(category, jsonObjectslist, position);
                    TextView textView = (TextView) view.findViewById(R.id.textview);
                    String clickvalue = textView.getText().toString();
                    System.out.println("CLICK VALUE INTENT" + clickvalue);
                    nextpage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    nextpage.putExtra("buttonvalue", clickvalue);
                    getApplicationContext().startActivity(nextpage);*//*
                    *//* FrameLayout f=(FrameLayout)findViewById(R.id.framelayout);
                    f.setVisibility(View.INVISIBLE);*//*
                FrameLayout s = (FrameLayout) findViewById(R.id.framelayouttwo);
                lv.setVisibility(View.GONE);
                s.setVisibility(View.VISIBLE);
                Fragment test = new listviewFrag();

                System.out.println("VISIBILITY ");
                System.out.println(test.isVisible() + "IS VISIBLE " + test.isAdded() + test.isInLayout());


                getFragmentManager().beginTransaction().replace(R.id.framelayouttwo, test, null).commit();

                System.out.println(test.isVisible() + "IS VISIBLE " + test.isAdded() + test.isInLayout());

                Toast.makeText(MainActivity.this, "ONCLICk LISTENER", Toast.LENGTH_SHORT).show();
                View v = test.getView();
            }
        });*/

    }

}
