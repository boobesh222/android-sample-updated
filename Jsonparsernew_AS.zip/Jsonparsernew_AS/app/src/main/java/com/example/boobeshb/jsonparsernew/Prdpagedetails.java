package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 10-03-2016.
 */
public class Prdpagedetails extends Activity {
    public static List<Bitmap> prdimages=new ArrayList<>();
    public static  List<Integer> pricelist=new ArrayList<Integer>();
    public static  List<String> sizelist=new ArrayList<String>();

    public Prdpagedetails() {
    }

    public Prdpagedetails(List<Bitmap> a,List<Integer> p,List<String> s) {
          prdimages=a;
         pricelist=p;
        sizelist=s;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landingpage);
        Bundle bundle=getIntent().getExtras();
        int position= bundle.getInt("POSITIONVALUE");
        ImageView productimage=(ImageView)findViewById(R.id.landingpage_imageviewone);
        TextView productsize=(TextView)findViewById(R.id.landingpage_size);
        TextView productprice=(TextView)findViewById(R.id.landingpage_textview);
        productimage.setImageBitmap(prdimages.get(position));
        productprice.setText("INR"+pricelist.get(position));
        productsize.setText("SIZE"+sizelist.get(position) );
    }
}
