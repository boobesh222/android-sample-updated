package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ViewFlipper;

/**
 * Created by boobeshb on 05-04-2016.
 */
public class Startfragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View v=inflater.inflate(R.layout.startfragment,null);
        ViewFlipper viewFlipper=(ViewFlipper)v.findViewById(R.id.viewflipper);
        viewFlipper.startFlipping();
        return v;
    }
}
