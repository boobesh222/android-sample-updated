package com.example.boobeshb.jsonparsernew;

import android.graphics.Bitmap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 24-03-2016.
 */


public class Retailappmodel  {

    public  static JSONObject jsonObject;
    public static List<Bitmap>  bitmapimages=new ArrayList<Bitmap>();
    public static   List<String> image= new ArrayList<String>();
    public static List<String> categorynames=new ArrayList<>();
    public static List<JSONObject> jsonObjectList=new ArrayList<JSONObject>();
    public static List<JSONArray> subcategoriesarray=new ArrayList<JSONArray>();
    public static List<String> varientsname=new ArrayList<String>();
    public static List<String> productsize=new ArrayList<String>();
    public static List<Bitmap> productimages=new ArrayList<Bitmap>();
    public static List price=new ArrayList();

    public Retailappmodel() {
    }

    public Retailappmodel(JSONObject jsonObject, List<Bitmap> bitmapimages) {
        this.jsonObject = jsonObject;
        this.bitmapimages = bitmapimages;
    }

    public Retailappmodel(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public List<Bitmap> getBitmapimages() {
        return bitmapimages;
    }

    public void setBitmapimages(List<Bitmap> bitmapimages) {
        this.bitmapimages = bitmapimages;
    }




    @Override
    public String toString() {
        return "Retailappmodel{" +
                "jsonObject=" + jsonObject +
                ", bitmapimages=" + bitmapimages +
                '}';
    }
}
