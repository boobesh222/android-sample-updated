package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by boobeshb on 23-03-2016.
 */
public class mensfragment extends Fragment {

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Bundle b=getArguments();
        new Fetchimage(getActivity(),b.getString("menu")).fetchimage();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        System.out.println("MENS FRAGMENTS DATA" + Retailappmodel.jsonObject.length());
        View v=inflater.inflate(R.layout.fragmentlayout,null);
        ListView listview=(ListView)v.findViewById(R.id.listview_fragmentlayout);
        System.out.println("BEFORE SETTING ADAPTER");

        listview.setAdapter(new Genericlistview(getActivity()));

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedmenu=Retailappmodel.categorynames.get(position);
                new Contentdetails(selectedmenu,getActivity(),position);
                Fragment fragment= new Innerlistviewfragment();
                getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment).addToBackStack("").commit();
                Toast.makeText(getActivity(), "selectedmenu" + selectedmenu, Toast.LENGTH_SHORT).show();
            }
        });

        return v;

    }
}
