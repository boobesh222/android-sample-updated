package com.example.boobeshb.jsonparsernew;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 30-03-2016.
 */
public class Productimageparse  extends AsyncTask <String, String, List<Bitmap>> {

    ProgressDialog prgdialog;
    Context c;

    public Productimageparse(Context context) {
        c = context;
        System.out.println("PRODUCT IMAGE PARSE CONSTRUCTOR ");
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        prgdialog = new ProgressDialog(c, ProgressDialog.STYLE_SPINNER);
        prgdialog.setMessage("Getting data.....");
        prgdialog.setIndeterminate(false);
        prgdialog.setCancelable(true);
        prgdialog.show();

    }

    @Override
    protected List<Bitmap> doInBackground(String... params) {
        Imageparser ip = new Imageparser();
        System.out.println(Retailappmodel.image.size() + "IMAGE SIZE PRODUCT IMAGE do in background");
        List<Bitmap> array = new ArrayList<Bitmap>();
        array.clear();
        for (int i = 0; i < Retailappmodel.image.size(); i++) {
            array.add(ip.getJSONfromURL(Retailappmodel.image.get(i)));
        }

        System.out.println("IMAGES ARRAY BITMAP" + "" + array.size() + "    ");
        /*for(Bitmap s:array){
            System.out.println(s.toString()+ "for loop bitmaps ");
        }*/
        Retailappmodel.productimages=array;
        return array;
    }




    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);

        System.out.println(values+"progress update values");
    }


    @Override
    protected void onPostExecute(List<Bitmap> bitmaps) {
        super.onPostExecute(bitmaps);
        prgdialog.dismiss();
        System.out.println("ONPOST EXECUTE PORDUCT IMAGE PARSEING");
        Retailappmodel.productimages=bitmaps;
        System.out.println("IMAGEPARSE ON POST EXECUTE" + bitmaps.size() + "   " + Retailappmodel.productimages.size());

    }

}


