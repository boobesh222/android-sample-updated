package com.example.boobeshb.cameraexample;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import com.soundcloud.android.crop.Crop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends ActionBarActivity {

    Uri fileuri;
    Uri croppedfileUri;
    public static final int MEDIA_TYPE_IMAGE=1;
    public static final int MEDIA_TYPE_IMAGECROPPED=3;
    public static final int MEDIA_TYPE_VIDEO=2;
    ImageView captturedimage;
    VideoView recordedvideo;
    Button croplefteye;
    Button croprighteye;
    ImageView lefteyeview;
    ImageView righteyeview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button captureImage=(Button)findViewById(R.id.image);

        Button recordVideo=(Button)findViewById(R.id.video);
        croplefteye=(Button)findViewById(R.id.capturelefteye_id);
        croprighteye=(Button)findViewById(R.id.capturerighteye_id);
        croplefteye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Crop.of(fileuri,croppedfileUri).withAspect(3,1).start(MainActivity.this,1000);

            }
        });

        croprighteye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Crop.of(fileuri,croppedfileUri).withAspect(3,1).start(MainActivity.this,1001);

            }
        });
        captturedimage=(ImageView)findViewById(R.id.capturedimage);
        //recordedvideo=(VideoView)findViewById(R.id.videoview);
        captureImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        /*recordVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recordlivevideo();
            }
        });*/

    }

    public void captureImage(){
        Intent intent =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        fileuri=getoutputmediauri(MEDIA_TYPE_IMAGE);
        croppedfileUri=getoutputmediauri(MEDIA_TYPE_IMAGECROPPED);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileuri);
        startActivityForResult(intent, 100);
    }

   public void recordlivevideo(){
       Intent intent=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
       fileuri=getoutputmediauri(MEDIA_TYPE_VIDEO);
       intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY,1);
       intent.putExtra(MediaStore.EXTRA_OUTPUT,fileuri);
       startActivityForResult(intent,200);
   }

    public Uri getoutputmediauri(int type){

        return  Uri.fromFile(getFile(type));
    }

    public static File getFile(int type){

        File mediastoragedirectory=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),"hellocamera");
        File destinationfile=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),"Croppedimages");
        if(!mediastoragedirectory.exists()){
            if(!mediastoragedirectory.mkdirs()){
                System.out.println("CREATING DIRECTORY FAILED");
                return null;
            }
        }
        if(!destinationfile.exists()){
            if(!destinationfile.mkdirs()){
                System.out.println("creating cropping directory failed");
                return null;

            }
        }


        String timeformat=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
       File Mediafile;
       File mediafileCropped;
        if(type==MEDIA_TYPE_IMAGE){
              Mediafile=new File(mediastoragedirectory,"Image"+".jpg");
            try{
                FileOutputStream outstream=new FileOutputStream(Mediafile);
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
            return  Mediafile;
        }else if(type==MEDIA_TYPE_IMAGECROPPED){
           // Mediafile=new File(mediastoragedirectory,"video"+timeformat);
            mediafileCropped=new File(destinationfile,"Image"+".jpg");
         return  mediafileCropped;
        }else{
            return null;
        }
      //  System.out.println("FILE PATH" + Mediafile.getAbsolutePath());
        //return Mediafile;
    }

    public void previewCapturedImage(){
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inSampleSize=8;
        Bitmap bitmap= BitmapFactory.decodeFile(fileuri.getPath(),options);
        captturedimage.setImageBitmap(bitmap);
        /*captturedimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Crop.pickImage(MainActivity.this);
                Crop.of(fileuri,croppedfileUri).withAspect(3,1).start(MainActivity.this);
            }
        });*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        System.out.println("REQUEST CODE" + requestCode +"  " + "RESULT CODE " + resultCode);


        /*if(requestCode ==6709){
               captturedimage.setImageURI(croppedfileUri);
        }*/

         if(requestCode == 1000){
             lefteyeview=(ImageView)findViewById(R.id.lefteyeview);
             lefteyeview.setImageResource(0);
             lefteyeview.setImageURI(croppedfileUri);
         }else if(requestCode == 1001){
             righteyeview=(ImageView)findViewById(R.id.righteyeview);
             righteyeview.setImageResource(0);
             righteyeview.setImageURI(croppedfileUri);
         }



        if(requestCode==100 ){

            if(resultCode== RESULT_OK ){
                System.out.println("RESULT CODE " + 100);
                /*new data for croping */
               // performcrop();
                /*end of cropping data */
                previewCapturedImage();
            }else if(resultCode==RESULT_CANCELED){
                Toast.makeText(MainActivity.this, " USER CANCELLED CAMERA OPERATION", Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode==200){
            if(resultCode== RESULT_OK){


            }else if(resultCode==RESULT_CANCELED){
                Toast.makeText(MainActivity.this, " USER CANCELLED VIDEO OPERATION", Toast.LENGTH_SHORT).show();
            }
        }
        else if( requestCode == Crop.RESULT_ERROR){
            Toast.makeText(MainActivity.this, "crop  error ", Toast.LENGTH_SHORT).show();
        }/*else if(requestCode == Crop.REQUEST_PICK && requestCode == RESULT_OK){
            System.out.println("REQUEST pickeing  BLOCK ");

            Crop.of(fileuri,croppedfileUri).asSquare().start(MainActivity.this);
        }else if( requestCode == Crop.REQUEST_CROP && requestCode == RESULT_OK){
            System.out.println("REQUEST CROPPING BLOCK ");
            if(croppedfileUri == null){
                System.out.println("cropped file uri  is null ");
            }

            captturedimage.setImageURI(croppedfileUri);
        }*/

        /*else if(requestCode==2){
            Bundle extras = data.getExtras();
            Bitmap images = extras.getParcelable("data");
            captturedimage.setImageBitmap(images);
        }*/

    }

    /*public void performcrop() {
        System.out.println("inside perform crop ");
        Intent intent = new Intent("com.android.camera.action.crop");
        intent.setDataAndType(fileuri, "image*//*");
        intent.putExtra("aspectX", 2);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 2);


    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
