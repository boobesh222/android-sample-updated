package com.example.boobeshb.cameraexample;

import android.app.Activity;

/**
 * Created by boobeshb on 20-05-2016.
 */
public class CropImageActivity extends Activity {
}
