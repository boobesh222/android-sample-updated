package com.example.boobeshb.youtubescreenexice;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    ListView l;

    int listImages[]={R.drawable.posterone,R.drawable.postertwo,R.drawable.posterthree,R.drawable.jurassic,R.drawable.hp,R.drawable.ava};
    String listNames[]={"Iron Man trailer","new armour suit","x men 3","JURASSIC PARK","hARRY POTTER","avator"};
    String description[]={"Iron Man is a fictional superhero appearing in American comic books published by Marvel Comics, as well as its associated media.",
    "Iron Man is a fictional superhero appearing in American comic books published by Marvel Comics, as well as its associated media.",
            "The X-Men film series consists of superhero films based on the Marvel Comics superhero team of the same name.",
    "Located off the coast of Costa Rica, the Jurassic World luxury resort provides a habitat for an array of genetically engineered dinosaurs, including the vicious and intelligent Indominus rex. When the massive creature escapes,",
            "Harry Potter is a series of seven fantasy novels and one play written by British author J. K. Rowling. ",
    "Jake, a paraplegic marine, replaces his brother on the Na'vi inhabited Pandora for a corporate mission. He is accepted by the natives as one of their own but he must decide where his loyalties lie."};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l=(ListView)findViewById(R.id.Main_listView);
        System.out.println("before custom adapter");
        l.setAdapter(new Customadapter(this, listNames, listImages));
        System.out.println("after custom adapter");

        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int s= (int)parent.getItemAtPosition(position);

                Intent nextscreen=new Intent(getApplicationContext(),Next.class);
                nextscreen.putExtra("image",listImages[s]);
                nextscreen.putExtra("name",listNames[s]);
                nextscreen.putExtra("description",description[s]);

                startActivity(nextscreen);
                Toast.makeText(getApplicationContext(),"s value"+s +"position "+position ,Toast.LENGTH_LONG).show();
            }
        });


     }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
